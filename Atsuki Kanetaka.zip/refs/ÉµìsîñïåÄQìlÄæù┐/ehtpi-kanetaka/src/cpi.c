#include "cpi.h"

//CP approaches: 11, 12, 13, 21, 221, 23
int ovnode_num;
//int nodes[10000];

void full_ob_setting(){
    L_NODE *fnode;
   FIN_NODE *finnode;
  finnode=ffnode.next;
  for(; finnode!=NULL; finnode=finnode->next){
    fnode=finnode->node;
  // if(fnode->line%2==0)
     fnode->op_flag = 1;
   }
}

void cpi_main(float cp_rate,char *cplist_path)
{

  printf("gate Tracing for structure info\n");
  printf("Parameter Initialization Begin\n");
  ini_for_testability();
  ini_for_trace();
  printf("Initialization End\nCP Selection process start\n");

  FILE *fout;
    fout=fopen(cplist_path,"w");
  if(fout==NULL) printf("cp_list file %s is not exist, check it!\n",cplist_path), exit(1);
    int ia=0,i_cp=0;
    CP_NUM=cp_rate*numgate;
    //CP_NUM=cp_rate*ffnum;

 printf("Expect CPNUM=%d : %f x %d\n",CP_NUM, cp_rate,numgate);
//printf("Expect CPNUM=%d : %f x %d\n",CP_NUM, cp_rate,ffnum);

    L_NODE **cp_lists;
    cp_lists = (L_NODE **)calloc(CP_NUM, sizeof(L_NODE *));
#if CAND_EXPLO==3
    L_NODE **candi_list;
    candi_list = (L_NODE **)calloc(numgate+1, sizeof(L_NODE *));
      int cplist_order[numgate+1];
#else
L_NODE **candi_list;
candi_list = (L_NODE **)calloc(CP_CANDI_NUM, sizeof(L_NODE *));
  int cplist_order[CP_CANDI_NUM];
#endif
#if CP_ALG==1
    int *nodes;
    nodes = (int *)calloc (numgate+1,sizeof(int));
  //  int nodes[numgate+1];
    ovnode_num=0;
    for(ia=0;ia<=numgate;ia++){
      nodes[ia]=0;
    }
#endif
    //  int sel_cp_num=0;
   node_fixgate_for_cpi();
#if OP_SEL_MODE==1
/*:::::全観測環境でＣＰ選定：：：：：：：：：：：：：*/
   full_ob_setting();
#endif
/*:::::全観測環境でＣＰ選定：：：：：：：：：：：：：*/
    while(i_cp<CP_NUM){
 printf("@# %d / %d CP selection \n",i_cp+1,CP_NUM);
//  for(i_cp=0;i_cp<CP_NUM;i_cp++){
  CPI_initiallization();
  printf("~Controllablity Computing start\n");
  for (ia=0; ia < Cap; ia++) {
    COP_C(ia);
  }
  printf("~Controllablity Computing End\n");
  printf("~Observability Computing start\n");
  for(ia=Cap;ia>0;ia--){
    COP_O(ia);
    }
  printf("~Observability Computing End\n");
  
#if CP_KANETAKA //kanetaka君の卒論アルゴリズム
  gt_forw_trace(gnode.next);
#endif
  int aviable_cp_num=0;
#if CAND_EXPLO==1
//extract candidate CP by COP & contribution
do{
    explor_candi_cp(candi_list);
    aviable_cp_num=rank_candi_cp_by_c(candi_list,cplist_order);
}while(!aviable_cp_num);

#endif

#if CAND_EXPLO==2
//extract candidate CP only by contribution
    aviable_cp_num=explor_candi_cp_v2(candi_list);
    for(ia=0;ia<aviable_cp_num;ia++) cplist_order[ia]=ia;
#endif
#if CAND_EXPLO==3
//extract candidate CP greedy
    aviable_cp_num=explor_candi_cp_every(candi_list);
    for(ia=0;ia<aviable_cp_num;ia++) cplist_order[ia]=ia;
#endif
/*
printf("\n");
for(ia=1;ia<=nodes[0];ia++){
  printf("%d | ",nodes[ia]);
}*/
  printf("\n@#%d / %d cp selection: 有効CP:%d/%d \n",i_cp+1,CP_NUM,aviable_cp_num,CP_CANDI_NUM );
  if(aviable_cp_num) {
#if CP_ALG==1
  if( pull_one_cp_by_DC(candi_list, aviable_cp_num,cplist_order,cp_lists,nodes,i_cp)==0){
#elif CP_ALG==2
  if(  pull_one_cp_by_contrib(candi_list, aviable_cp_num,cplist_order,cp_lists,i_cp)==0){
#elif CP_ALG==3
#if TP_EVALU_METRIC
  #if CP_KANETAKA //kanetaka君の卒論アルゴリズム
    if(pull_one_cp_by_boundary(candi_list, aviable_cp_num,cplist_order,cp_lists,i_cp)==0){
  #else
    if(pull_one_cp_by_cost(candi_list, aviable_cp_num,cplist_order,cp_lists,i_cp)==0){
  #endif
#else
    if(pull_one_cp_by_expfc(candi_list, aviable_cp_num,cplist_order,cp_lists,i_cp)==0){
#endif
#endif
  //  int pull_one_cp_by_DC(candi_list, aviable_cp_num, cplist_order,cp_lists,nodes,node_num, sel_cp_num)
  printf("Pull #%d CP was successed: %d %d %d\n",i_cp+1,cp_lists[i_cp]->line,cp_lists[i_cp]->type,cp_lists[i_cp]->line- inpnum - numout -ffnum);

  //fprintf(fout, "%d, %d\n",cp_lists[i_cp]->line - inpnum - numout -ffnum, cp_lists[i_cp]->type);
    fprintf(fout, "%d\n",cp_lists[i_cp]->line - inpnum - numout -ffnum);
 
    refresh_all_cpnode();
    i_cp++;
        //    printf("orig_cost=%Lf, current_cost=%Lf, reduction rate=%f\n",original_cost,new_cost,(new_cost/original_cost)*100);
    }
  else   {
    printf("#%d CP is not determine yet, continute...\n",i_cp+1);
        printf("orig_cost=%Lf, current_cost=%Lf, reduction rate=%Lf\n",original_cost,new_cost,(original_cost-new_cost)/original_cost*100);
    #if CP_KANETAKA //kanetaka君の卒論アルゴリズム
     if(all_routing_finish_check()==0){
    #else
  if(all_routing_finish_check()==0||(original_cost-new_cost)/original_cost*100>cost_reducion_thd){
    #endif
  printf("all nodes have been checked, not additional suitable cp was found\n CP selection will be ended here\n");
  printf("Selected CP number = %d\n ",i_cp+1);
  for(ia=0;ia<i_cp;ia++)
  printf("cp_%d: %d %d\n",ia+1,cp_lists[ia]->line,cp_lists[ia]->type);
  break;
  }
  else{
  for(ia=0;ia<CP_CANDI_NUM;ia++)
    candi_list[ia]->cp_flag=0;
  }
}
}
else {
    printf("@#%d CP selection: 有効なcpが見つかりませんでした！Check other Gates!\n",i_cp+1);
    #if CP_KANETAKA //kanetaka君の卒論アルゴリズム
     if(all_routing_finish_check()==0){
    #else
    if(all_routing_finish_check()==0||(original_cost-new_cost)/original_cost*100>cost_reducion_thd){
    #endif
    printf("all nodes have been checked, not additional suitable cp was found\n CP selection will be ended here\n");
    printf("Selected CP number = %d\n ",i_cp+1);
    for(ia=0;ia<i_cp;ia++)
    printf("cp_%d: %d %d\n",ia+1,cp_lists[ia]->line,cp_lists[i_cp]->type);
    break;
    }
    else{
          for(ia=0;ia<CP_CANDI_NUM;ia++)
            candi_list[ia]->cp_flag=0;
    }
}

  }
free(candi_list);
fclose(fout);
free(cp_lists);
}


float contribution_cal(int fix0, int fix1, float p0)
{
return (float)(p0-0.5)*fix0+(0.5-p0)*fix1;
}

void refresh_all_cpnode(){
  L_NODE *fnode;
  FIN_NODE *finnode;
  finnode=ffnode.next;
   for(; finnode!=NULL; finnode=finnode->next){
      fnode=finnode->node;         // printf("^%d,%d^ ",fnode->line,fnode->cand_flag);
      fnode->cand_flag=0;
      fnode->cp_flag=0;
    }
  fnode=gnode.next;
  for(; fnode!=NULL; fnode=fnode->next){ //printf("locate explor %f, %f, %f\n",fnode->C0[1],fnode->C0[Cap+2]/Cap,c0val);
  //printf("^%d,%d^ ",fnode->line,fnode->cand_flag);
        fnode->cand_flag=0;
        fnode->cp_flag=0;
      }
}

int all_routing_finish_check(){
  L_NODE *fnode;
  FIN_NODE *finnode;
  int flag=0;
  #if FF_CP_SEL
  finnode=ffnode.next;
   for(; finnode!=NULL; finnode=finnode->next){
      fnode=finnode->node;         // printf("^%d,%d^ ",fnode->line,fnode->cand_flag);
      //if(!fnode->cand_flag) {flag=1;break;}
      if(!fnode->cand_flag&&fnode->contri[0]>0.0) {flag=1;break;}
    }
if(flag) return -1;
#endif
//else{
  fnode=gnode.next;
  for(; fnode!=NULL; fnode=fnode->next){ //printf("locate explor %f, %f, %f\n",fnode->C0[1],fnode->C0[Cap+2]/Cap,c0val);
  //printf("^%d,%d^ ",fnode->line,fnode->cand_flag);
  //if(!fnode->cand_flag) {flag=1;break;}
  if(!fnode->cand_flag&&fnode->contri[0]>0.0) {flag=1;break;}
      }
  //}
if(flag) return -1;
else return 0;
}

void node_fixgate_for_cpi(){
  L_NODE *fnode;
  FIN_NODE *finnode;
  #if FF_CP_SEL
  finnode=ffnode.next;
   for(; finnode!=NULL; finnode=finnode->next){
      fnode=finnode->node;         // printf("^%d,%d^ ",fnode->line,fnode->cand_flag);
      gt_forw_trace_for_cpi_single(fnode);
  }
    #endif
      gt_forw_trace_for_cpi(gnode.next);
}

int explor_candi_cp_v2(L_NODE *candi_list[])
{
int ia,cnd_cnt=0;
L_NODE *fnode;
FIN_NODE *finnode;

float maxval=0.0;
float eval=0.0;
   printf("candinate CP List\n");
cnd_cnt=0;
for(ia=0;ia<CP_CANDI_NUM;ia++){
     maxval=0.0; eval=0.0;
     int flag=0;
#if FF_CP_SEL
   finnode=ffnode.next;
    for(; finnode!=NULL; finnode=finnode->next){
       fnode=finnode->node;         // printf("^%d,%d^ ",fnode->line,fnode->cand_flag);
     fnode->contri[0]=0.0;
       if(fnode->cand_flag||fnode->sel_flag||fnode->type==PO) continue;
       fnode->contri[0]=contribution_cal(fnode->fix_gt_0,fnode->fix_gt_1,fnode->C0[Cap+2]/Cap);
    //if(fnode->line==127)  printf("^%d,%f^ ",fnode->line,fnode->contri[0]),exit(1);
       if(fnode->contri[0]>=maxval&&fnode->contri[0]!=0.0){
          maxval=fnode->contri[0];
          candi_list[ia]=fnode;
             flag++;
        }
     }
#endif

  fnode=gnode.next;
     for(; fnode!=NULL; fnode=fnode->next){ //printf("locate explor %f, %f, %f\n",fnode->C0[1],fnode->C0[Cap+2]/Cap,c0val);
 //printf("^%d,%d^ ",fnode->line,fnode->cand_flag);
      fnode->contri[0]=0.0;
       if(fnode->cand_flag||fnode->sel_flag||fnode->type==PO) continue;
       //cnd_cnt++;
      fnode->contri[0]=contribution_cal(fnode->fix_gt_0,fnode->fix_gt_1,fnode->C0[Cap+2]/Cap);
     //printf("^%d,%f^ ",fnode->line,fnode->contri[0]);
       if(fnode->contri[0]>=maxval&&fnode->contri[0]!=0.0){
         maxval=fnode->contri[0];
         candi_list[ia]=fnode;
        flag++;
       }
    }
    if(flag) {
      candi_list[cnd_cnt]->cand_flag=1;
      cnd_cnt++;
  }
    printf("%d %d,%d %f\n",ia,cnd_cnt,candi_list[cnd_cnt-1]->line,candi_list[cnd_cnt-1]->contri[0]);
  }
     printf("\n");
     return cnd_cnt;
}


int explor_candi_cp_every(L_NODE *candi_list[])
{
int ia,cnd_cnt=0;
L_NODE *fnode;
FIN_NODE *finnode;

float maxval=0.0;
float eval=0.0;
   printf("candinate CP List\n");
cnd_cnt=0;
for(ia=0;ia<numgate;ia++){
     maxval=0.0; eval=0.0;
     int flag=0;
#if FF_CP_SEL
   finnode=ffnode.next;
    for(; finnode!=NULL; finnode=finnode->next){
       fnode=finnode->node;         // printf("^%d,%d^ ",fnode->line,fnode->cand_flag);
       if(fnode->cand_flag||fnode->sel_flag||fnode->type==PO) continue;
    //if(fnode->line==127)  printf("^%d,%f^ ",fnode->line,fnode->contri[0]),exit(1);
          candi_list[ia]=fnode;
             flag++;
     }
#endif

  fnode=gnode.next;
     for(; fnode!=NULL; fnode=fnode->next){ //printf("locate explor %f, %f, %f\n",fnode->C0[1],fnode->C0[Cap+2]/Cap,c0val);
 //printf("^%d,%d^ ",fnode->line,fnode->cand_flag);
       if(fnode->cand_flag||fnode->sel_flag||fnode->type==PO) continue;
       //cnd_cnt++;
     //printf("^%d,%f^ ",fnode->line,fnode->contri[0]);
         candi_list[ia]=fnode;
        flag++;
    }
    if(flag) {
      candi_list[cnd_cnt]->cand_flag=1;
      cnd_cnt++;
  }
  //  printf("%d %d,%d \n",ia,cnd_cnt,candi_list[cnd_cnt-1]->line);
  }
     printf("\n");
     return cnd_cnt;
}


void explor_candi_cp(L_NODE *candi_list[])
{
int ia,cnd_cnt=0;
L_NODE *fnode;
FIN_NODE *finnode;

float maxval=0.0;
float eval=0.0;
   printf("candinate CP List\n");
for(ia=0;ia<CP_CANDI_NUM;ia++){
  maxval=0.0;cnd_cnt=0; eval=0.0;
  #if FF_CP_SEL
  finnode=ffnode.next;
   for(; finnode!=NULL; finnode=finnode->next){
      fnode=finnode->node;         // printf("^%d,%d^ ",fnode->line,fnode->cand_flag);
      if(fnode->cand_flag||fnode->sel_flag) continue;
      cnd_cnt++;
    //  eval=fabs((float)(fnode->C0[1]-fnode->C0[Cap+2]/Cap));
      eval=fnode->C0[Cap+2]/Cap;
    	if(eval>maxval){
        maxval=eval;
        candi_list[ia]=fnode;
      }
  	}
  #endif

    fnode=gnode.next;
    for(; fnode!=NULL; fnode=fnode->next){ //printf("locate explor %f, %f, %f\n",fnode->C0[1],fnode->C0[Cap+2]/Cap,c0val);
//printf("^%d,%d^ ",fnode->line,fnode->cand_flag);
      if(fnode->cand_flag||fnode->sel_flag||fnode->type==PO) continue;
      cnd_cnt++;
    //  eval=fabs(fnode->C0[1]-fnode->C0[Cap+2]/Cap);
      eval=fnode->C0[Cap+2]/Cap;
      if(eval>maxval){
        maxval=eval;
        candi_list[ia]=fnode;
          //  printf("locate explor X %f, %f, %f,%d\n",fnode->C0[1],fnode->C0[Cap+2]/Cap,eval,Cap);
        }
     }
     candi_list[ia]->cand_flag=1;
     printf("%d, ",candi_list[ia]->line);
   }
   printf("\n");
}



void refresh_candi_cp(L_NODE **candi_list)
{
  int ia;
     printf("refresh the candidate CP List\n");
  for(ia=0;ia<CP_CANDI_NUM;ia++){
    if(candi_list[ia]==NULL) continue;
    candi_list[ia]->cand_flag=0;
    candi_list[ia]->cp_flag=0;
  }
}


int pull_one_cp_by_cost(L_NODE **candi_list, int aviable_cp_num, int cplist_order[], L_NODE *cp_lists[], int sel_cp_num)
{
  int ia,ib;
  long long int cost_orig,cost_new;
  long long int cost_delta_min;
//  double cost_orig,cost_new;
//  double cost_delta_min;
 cost_orig=cost_func_cal();
 if(sel_cp_num==0) original_cost=cost_orig;
 new_cost=cost_orig;

L_NODE *tmp_node;
int node_num=-1;
//cost_delta_min=0;
cost_delta_min=0.0;
  for(ia=0;ia<aviable_cp_num;ia++){
    if(candi_list[cplist_order[ia]]->sel_flag) {
    //  printf("Yes %d\n", candi_list[cplist_order[ia]]->line,candi_list[cplist_order[ia]]->cp_flag);
      continue;
    }
    candi_list[cplist_order[ia]]->cp_flag=1;
    //printf("candi_cp %d, type=%d, cp_flag=%d\n",candi_list[ia]->line, candi_list[ia]->type,candi_list[ia]->cp_flag);

  CPI_initiallization();
    for (ib=0; ib < Cap; ib++) {
      COP_C(ib);
    }
    for(ib=Cap;ib>0;ib--){
      COP_O(ib);
    }
    cost_new=cost_func_cal();    //  printf("debug\n");
//  printf("COST %f->%f \n",cost_orig,cost_new);
  //   printf("candinode: %d  cost:%f\n",candi_list[cplist_order[ia]]->line,cost_orig-cost_new);
    printf("COST %lld->%lld \n",cost_orig,cost_new);
      printf("candinode: %d  cost:%lld\n",candi_list[cplist_order[ia]]->line,cost_orig-cost_new);
    if((cost_orig-cost_new)>cost_delta_min){
      cost_delta_min=cost_orig-cost_new;
      tmp_node=candi_list[cplist_order[ia]];
      node_num=cplist_order[ia];
    }
   candi_list[cplist_order[ia]]->cp_flag=0;
          //  fnode->cp_flag=0;
  }

  if(node_num>=0){

  //  if(node_num)  sel_cp_num++;
  //  printf("selected node: %d  %d \n",node_num,sel_cp_num);
    cp_lists[sel_cp_num]=tmp_node;
    cp_lists[sel_cp_num]->sel_flag=1;
    printf("selected node #%d: %d \n",sel_cp_num,cp_lists[sel_cp_num]->line);
    return 0;
  }
  else {
    return -1;
  }
}

#if CP_KANETAKA //kanetaka君の卒論アルゴリズム
int pull_one_cp_by_boundary(L_NODE **candi_list, int aviable_cp_num, int cplist_order[], L_NODE *cp_lists[], int sel_cp_num)
{
  int ia,ib;
  double **items;


 items = (double **)calloc(aviable_cp_num, sizeof(double *));
 for(ia=0;ia<aviable_cp_num;ia++){
 items[ia]=(double *)calloc(3, sizeof(double));
  boundary_node_search(candi_list[cplist_order[ia]]);
 
 }
for(ia=0;ia<aviable_cp_num;ia++){ 
  items[ia][0]=contribution_cal(candi_list[cplist_order[ia]]->fix_gt_0,candi_list[cplist_order[ia]]->fix_gt_1,candi_list[cplist_order[ia]]->C0[Cap+2]/Cap);
  items[ia][1]=candi_list[cplist_order[ia]]->boundary_node_num;
  items[ia][2]=observability_boundary_nodes(candi_list[cplist_order[ia]]);
}

node_num=topsis_cal_gener(items,3,aviable_cp_num);

  if(node_num>=0){
    cp_lists[sel_cp_num]=candi_list[cplist_order[node_num]];
    cp_lists[sel_cp_num]->sel_flag=1;
    printf("selected node #%d: %d \n",sel_cp_num,cp_lists[sel_cp_num]->line);
    return 0;
  }
  else {
    return -1;
  }
free(*items);
free(items);
}
#endif

int pull_one_cp_by_expfc(L_NODE **candi_list,int aviable_cp_num,int cplist_order[],L_NODE *cp_lists[],int sel_cp_num)
{
  int ia,ib;
double exfc_orig=0.0;
double exfc_new=0.0, exfc_delta_max=0.0;
L_NODE *tmp_node;
int node_num=-1;
exfc_orig=exp_fc_cal_per_pat(PATNUM);
 exfc_delta_max=FCOV_INCREMENT_BOUND;
//printf("exfc original %f ",exfc_orig);
  for(ia=0;ia<aviable_cp_num;ia++){
    if(candi_list[cplist_order[ia]]->sel_flag) {
      printf("Yes %d %d\n", candi_list[cplist_order[ia]]->line,candi_list[cplist_order[ia]]->cp_flag);
      continue;
    }
    candi_list[cplist_order[ia]]->cp_flag=1;
    //printf("candi_cp %d, type=%d, cp_flag=%d\n",candi_list[ia]->line, candi_list[ia]->type,candi_list[ia]->cp_flag);
  CPI_initiallization();
    for (ib=0; ib < Cap; ib++) {
      COP_C(ib);
    }
    for(ib=Cap;ib>0;ib--){
      COP_O(ib);
    }
    exfc_new=exp_fc_cal_per_pat(PATNUM);

  //  printf("exfc original %f ",exfc_orig);printf("->%f\n",exfc_new);
  //  printf("candinode: ia=%d  %d  cost:%f\n",ia,candi_list[cplist_order[ia]]->line,exfc_new-exfc_orig);
    if((exfc_new-exfc_orig)>exfc_delta_max){
      exfc_delta_max=exfc_new-exfc_orig;
      tmp_node=candi_list[cplist_order[ia]];
      node_num=cplist_order[ia];
    }
    candi_list[cplist_order[ia]]->cp_flag=0;
          //  fnode->cp_flag=0;
    printf("%d ",ia);
    if(ia%20==0)   printf("\n");
  }

  if(node_num>=0){
  //  if(node_num)  sel_cp_num++;
  //  printf("selected node: %d  %d \n",node_num,sel_cp_num);
    cp_lists[sel_cp_num]=tmp_node;
    cp_lists[sel_cp_num]->sel_flag=1;
  //  printf("selected node #%d: %d \n",sel_cp_num,cp_lists[sel_cp_num]->line);
    return 0;
  }
  else {
    return -1;
  }
}


int pull_one_cp_by_contrib(L_NODE **candi_list,int aviable_cp_num,int cplist_order[],L_NODE *cp_lists[],int sel_cp_num)
{

//for(ia=0;ia<aviable_cp_num;ia++)
if(candi_list[0]!=NULL){
   cp_lists[sel_cp_num]=candi_list[cplist_order[0]];
    cp_lists[sel_cp_num]->sel_flag=1;
    printf("selected node #%d: %d \n",sel_cp_num,cp_lists[sel_cp_num]->line);
    return 0;
  }
  else return -1;

}

int pull_one_cp_by_DC(L_NODE **candi_list,int aviable_cp_num,int cplist_order[],L_NODE *cp_lists[],int nodes[],int sel_cp_num)
{
float unoverlap_max=0.0;
float unoverlap_gt;
int tmp_cp=-1;
int ia;

for(ia=0;ia<aviable_cp_num;ia++){
  if(candi_list[cplist_order[ia]]->sel_flag) {
    printf("Yes %d %d\n", candi_list[cplist_order[ia]]->line,candi_list[cplist_order[ia]]->cp_flag);
    continue;
  }
    unoverlap_gt=0.0;
  //  printf("node %d ~ %d \n",cplist_order[ia],unoverlap_gt);
  unoverlap_gt=  gt_forw_trace_for_overlap(candi_list[cplist_order[ia]],nodes);
printf("node %d ~ %f \n",candi_list[cplist_order[ia]]->line,unoverlap_gt);
if(unoverlap_gt>unoverlap_max){
  unoverlap_max=unoverlap_gt;
  tmp_cp=cplist_order[ia];
}
  //candi_list[cplist_order[ia]]->cp_flag=0;
}

if(tmp_cp>=0){
  //printf("herer%d\n",tmp_cp);
  cp_lists[sel_cp_num]=candi_list[tmp_cp];
  cp_lists[sel_cp_num]->sel_flag=1;
  //  printf("\nselected node #%d: %d \n",sel_cp_num,cp_lists[sel_cp_num]->line);
  gt_forw_trace_for_overlap_updata(cp_lists[sel_cp_num],nodes);
//  printf("\nselected node #%d: %d \n",sel_cp_num,cp_lists[sel_cp_num]->line);
  return 0;
}
else {
  return -1;
}

}

void gt_forw_trace_for_overlap_updata(L_NODE *origin_node,int *nodes)
{
  int ia,ib,Node1Num,Node2Num,flag, flag1;
  FIN_NODE *fanoutlst;
  L_NODE *fnode,*fnode1,*fnode2,**node1,**temnode;
  node1 = (L_NODE **)calloc(numgate+1, sizeof(L_NODE *));
  temnode=(L_NODE **)calloc(numgate+1, sizeof(L_NODE *));
  int ic;

//  printf("\nin->Overlap gates = \n");
  fnode=origin_node;
   for(ia=0;ia<numgate;ia++)
    node1[ia]=NULL;
   node1[0]=fnode;
   Node1Num=1;
   while(Node1Num>0){
     Node2Num=0;
     for(ia=0;ia<numgate;ia++)temnode[ia]=NULL;
 ///////////////////////////////////////////////////////////////////////////////
     for(ia=0;ia<Node1Num;ia++){
       fnode1=node1[ia];
    //   printf("%d %d %d ",fnode1->line,fnode1->type,fnode1->fltList[0]);
       fanoutlst=fnode1->foutlst;
       for(;fanoutlst!=NULL;fanoutlst=fanoutlst->next){
         fnode2=fanoutlst->node;

  //     fnode2->fix0=0;fnode2->fix1=0;
         flag=0;
         for(ib=0;ib<Node2Num;ib++){
           if(temnode[ib]==fnode2){
             flag=1;break;
               }
             }
         if(flag==0){
           temnode[Node2Num]=fnode2;
           Node2Num++;
           }
         }
       }
 ////////////////////////////////////////////////////////////////////////////
  for(ia=0;ia<Node1Num+1;ia++) node1[ia]=NULL;
   Node1Num=0;
   for(ia=0;ia<Node2Num;ia++){
       if(temnode[ia]->type!=FF&&temnode[ia]->type!=PO){
             flag=0;
              for(ib=1;ib<=nodes[0];ib++){
               if(temnode[ia]->line==nodes[ib]) {flag++;
                 //break;
               }
              }
              if(flag==0) {
                nodes[0]++;
                nodes[nodes[0]]=temnode[ia]->line;
              }

         node1[Node1Num]=temnode[ia];
         Node1Num++;
         }
       }
 ////////////////////////////////////////////////////////////////////////////
   }
//printf("\nOverlap gates = %d \n",nodes[0] );
free(node1);
  free(temnode);
}

#if CP_KANETAKA //kanetaka君の卒論アルゴリズム
float observability_boundary_nodes(L_NODE *origin_node)
{
  int ia,ib;
  float ave_obs=0.0;
  L_NODE *fnode;
  fnode=origin_node;
  for(ia=0;ia<fnode->boundary_node_num;ia++){
    for(ib=0;ib<Cap;ib++){
      ave_obs+= fnode->boundary_node[ia]->O[ib+1];
    }
     // printf("%f ", ave_obs);
  }
  return ave_obs/=(float)fnode->boundary_node_num*Cap;
  
}
#endif

float gt_forw_trace_for_overlap(L_NODE *origin_node,int *nodes)
{
  int ia,ib,Node1Num,Node2Num,flag, flag1;
  FIN_NODE *fanoutlst;
  L_NODE *fnode,*fnode1,*fnode2,**node1,**temnode;
  node1 = (L_NODE **)calloc(numgate+1, sizeof(L_NODE *));
  temnode=(L_NODE **)calloc(numgate+1, sizeof(L_NODE *));
  int ic;
  int unoverlap_gt=0;
  int trace_gt_cnt=0;
//printf("\nin->Overlap gates = %d %d \n",unoverlap_gt, nodes[0]);
fnode=gnode.next;
for(; fnode!=NULL; fnode=fnode->next) fnode->traced_flag=0;

  fnode=origin_node;
   for(ia=0;ia<numgate;ia++)
    node1[ia]=NULL;
   node1[0]=fnode;
   Node1Num=1;
   while(Node1Num>0){
     Node2Num=0;
     for(ia=0;ia<numgate;ia++)temnode[ia]=NULL;
 ///////////////////////////////////////////////////////////////////////////////
     for(ia=0;ia<Node1Num;ia++){
       fnode1=node1[ia];
       //printf("%d %d %d ",fnode1->line,fnode1->type,fnode1->fltList[0]);
       fanoutlst=fnode1->foutlst;
       for(;fanoutlst!=NULL;fanoutlst=fanoutlst->next){
         fnode2=fanoutlst->node;

  //     fnode2->fix0=0;fnode2->fix1=0;
         flag=0;
         for(ib=0;ib<Node2Num;ib++){
           if(temnode[ib]==fnode2){
             flag=1;break;
               }
             }
         if(flag==0){
           temnode[Node2Num]=fnode2;
           Node2Num++;
           }
         }
       }
 ////////////////////////////////////////////////////////////////////////////
  for(ia=0;ia<Node1Num+1;ia++) node1[ia]=NULL;
   Node1Num=0;
   for(ia=0;ia<Node2Num;ia++){
       if(temnode[ia]->type!=FF&&temnode[ia]->type!=PO){
             flag=0;
              for(ib=1;ib<=nodes[0];ib++){
               if(temnode[ia]->line==nodes[ib]) {flag++;
              //  break;
               }
              }
              if(flag==0 && !temnode[ia]->traced_flag) {
                unoverlap_gt++;
                            }
              if(!temnode[ia]->traced_flag)   trace_gt_cnt++;
              temnode[ia]->traced_flag=1;
         node1[Node1Num]=temnode[ia];
         Node1Num++;
         }
       }
 ////////////////////////////////////////////////////////////////////////////
   }

free(node1);
  free(temnode);
  float overlap_rate=(float)unoverlap_gt/(trace_gt_cnt+nodes[0]);
  printf("\nOverlap gates = %d %d %d %f\n",unoverlap_gt,trace_gt_cnt,nodes[0],overlap_rate);
  if(overlap_rate==1.0) return unoverlap_gt;
  else  return overlap_rate;
}

void swap_node(L_NODE *node1,L_NODE *node2)
{
  L_NODE temp;
  temp = *node1;
  *node1=*node2;
  *node2=temp;
}

void swap_float(float *a, float *b)
{
  float temp;
  temp = *a;
  *a=*b;
  *b=temp;
}
void swap_int(int *a,int *b)
{
  int temp;
  temp = *a;
  *a=*b;
  *b=temp;
}

int rank_candi_cp_by_c(L_NODE **candi_list,int cplist_order[]) //有効な候補CP数を返す
{

int isort,ia;
float contri_val[CP_CANDI_NUM],max_val=0.0;

int node_num=0;

for(ia=0;ia<CP_CANDI_NUM;ia++){
gt_forw_trace_for_cpi_single(candi_list[ia]);
contri_val[ia]=contribution_cal(candi_list[ia]->fix_gt_0,candi_list[ia]->fix_gt_1,candi_list[ia]->C0[Cap+2]/Cap);
cplist_order[ia]=ia;
}

for(isort=0; isort<CP_CANDI_NUM-1;isort++){
    max_val=0.0;
  for(ia=isort+1;ia<CP_CANDI_NUM;ia++){
    if(contri_val[isort]<contri_val[ia]){
    //swap_node(candi_list[isort],candi_list[ia]);
    swap_int(&cplist_order[isort],&cplist_order[ia]);
   swap_float(&contri_val[isort],&contri_val[ia]);
  }
  }
  if(contri_val[isort]>0) node_num++;
}

  return node_num;
}
