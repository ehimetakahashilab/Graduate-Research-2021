
#include"struct_eval.h"

void ff_forw_trace(FIN_NODE *ff_head)
{
	int in,ia,ib,Node1Num,Node2Num,flag,stop_flag;
 	L_NODE *fnode,*fnode1,*fnode2,**node1,**temnode;
 	FIN_NODE *finnode,*fanoutlst;
	int width[MaxLevel+1],tmp_width;
node1 = (L_NODE **)calloc(numgate+2, sizeof(L_NODE *));
temnode=(L_NODE **)calloc(numgate+2, sizeof(L_NODE *));

if(node1 == NULL)     printf("memory error @node1\n"), exit(1);
if(temnode == NULL)    printf("memory error @temnode\n"), exit(1);

printf("ffnum=%d gate_num=%d\n",ffnum,numgate);

  	finnode=ff_head;
//search the faults observed by each FF

  for(in=0;finnode!=NULL;finnode=finnode->next,in++){
	Node1Num=0;
	for(ia=0;ia<numgate;ia++)
		node1[ia]=NULL;
	for(ia=0;ia<=MaxLevel;ia++)
		width[ia]=0;
	fnode=finnode->node;
	node1[0]=fnode;
	Node1Num=1;
	fnode->fw_branch=0;
	fnode->fw_depth=0;
	fnode->fw_width=0;
	fnode->fw_po_dis=0;
	stop_flag=0;//fwtracing stop point when a Po or FF is found;
	for(ia=0;ia<ffnum;ia++)
		fnode->ff_out_path[ia]=0;

	while(Node1Num>0){

		Node2Num=0;

		if(fnode==node1[0]){
			fnode->eval_C[5]=0;
			fnode->eval_C[6]=0;
			}
		else {
		fnode->eval_C[6]++;
		fnode->eval_C[5]+=Node1Num;
			}
		for(ia=0;ia<numgate;ia++)temnode[ia]=NULL;
///////////////////////////////////////////////////////////////////////////////
		for(ia=0;ia<Node1Num;ia++){
			fnode1=node1[ia];
			width[fnode1->level]++;
			//printf("fnode1: %d %d %d \n",fnode1->line,fnode1->type,fnode1->level);
			if(fnode1->nfout>1) fnode->fw_branch+=fnode1->nfout;
			fanoutlst=fnode1->foutlst;
			for(;fanoutlst!=NULL;fanoutlst=fanoutlst->next){
				fnode2=fanoutlst->node;
			//printf("%d %d %d \n",fnode2->line,fnode2->type,fnode2->level);

				//if(fnode2==fnode) continue;
				flag=0;
				for(ib=0;ib<Node2Num;ib++){
					if(temnode[ib]==fnode2){
						flag=1;break;
							}
						}
				if(flag==0){
					temnode[Node2Num]=fnode2;
					Node2Num++;
					}
				}
			}

////////////////////////////////////////////////////////////////////////////

	for(ia=0;ia<numgate;ia++) node1[ia]=NULL;
	Node1Num=0;

/*		printf("level_width= ");
	for(ia=0;ia<=MaxLevel;ia++)
		printf("%d ",width[ia]);
	printf("\n");
*/

	for(ia=0;ia<Node2Num;ia++){
			if(temnode[ia]->type==PO)
				stop_flag=1;
			if(temnode[ia]->type==FF){

				fnode->ff_out_path[fnode->eval_C[4]]=temnode[ia]->line;
				fnode->eval_C[4]++;
#if Debug
				if(fnode->line==temnode[ia]->line)
printf("FF%d: %d %d %d \n",fnode->line, temnode[ia]->type, temnode[ia]->line,fnode->eval_C[4]);//exit(1);
#endif
			}
			if(temnode[ia]->type!=FF&&temnode[ia]->type!=PO){
#if NODE_REC
					flag=0;
				for(ib=0;ib<fnode->fw_traced_node_num;ib++){
					if(temnode[ia]==fnode->fw_traced_node[ib]){
							flag=1; break;
							}
						}
				if(flag==1) continue;
				if(temnode[ia]->level>=fnode->fw_depth) fnode->fw_depth=temnode[ia]->level;
				fnode->fw_traced_node[fnode->fw_traced_node_num] = temnode[ia];
				fnode->fw_traced_node_num++;
				//printf("%d %d %d hehre?\n",Node2Num,fnode->fw_traced_node_num,temnode[ia]->level);
				//fnode->fw_gt_list[0]++;
				//fnode->fw_gt_list[fnode->fw_gt_list[0]]=temnode[ia]->line;
#endif
				node1[Node1Num]=temnode[ia];
				Node1Num++;

				}
			}
		if(stop_flag==0) fnode->fw_po_dis++;
////////////////////////////////////////////////////////////////////////////
	}

	//fnode->fw_width=0;
	for(ia=0;ia<=MaxLevel;ia++)
		if(width[ia]>=fnode->fw_width) fnode->fw_width=width[ia];

	//if(Node2Num>=fnode->fw_width) fnode->fw_width=Node2Num;
//exit(1);
}
free(node1);
free(temnode);
}

//前方追跡：単一ノードから、追跡のみ、記録なし、必要に応じてノードを記録してください。
void ff_forw_trace_single(FIN_NODE *origin_node)
{
	int in,ia,ib,Node1Num,Node2Num;
 	L_NODE *fnode,*fnode1,*fnode2,**node1,**temnode;
 	FIN_NODE *finnode,*fanoutlst;
node1 = (L_NODE **)calloc(numgate+2, sizeof(L_NODE *));
temnode=(L_NODE **)calloc(numgate+2, sizeof(L_NODE *));

if(node1 == NULL)     printf("memory error @node1\n"), exit(1);
if(temnode == NULL)    printf("memory error @temnode\n"), exit(1);

printf("ffnum=%d gate_num=%d\n",ffnum,numgate);

	Node1Num=0;
	for(ia=0;ia<numgate;ia++)
		node1[ia]=NULL;
	fnode=origin_node->node;
	node1[0]=fnode;
	Node1Num=1;
//	int stop_flag=0;//fwtracing stop point when a Po or FF is found;

	while(Node1Num>0){
		Node2Num=0;

		for(ia=0;ia<numgate;ia++)temnode[ia]=NULL;
///////////////////////////////////////////////////////////////////////////////
		for(ia=0;ia<Node1Num;ia++){
			fnode1=node1[ia];

			fanoutlst=fnode1->foutlst;
			for(;fanoutlst!=NULL;fanoutlst=fanoutlst->next){
				fnode2=fanoutlst->node;
			//printf("%d %d %d \n",fnode2->line,fnode2->type,fnode2->level);
				//if(fnode2==fnode) continue;
				int flag=0;
				for(ib=0;ib<Node2Num;ib++){
					if(temnode[ib]==fnode2){
						flag=1;break;
							}
						}
				if(flag==0){
					temnode[Node2Num]=fnode2;
					Node2Num++;
					}
				}
			}

	for(ia=0;ia<numgate;ia++) node1[ia]=NULL;
	Node1Num=0;

	for(ia=0;ia<Node2Num;ia++){
			if(temnode[ia]->type==PO)
				//stop_flag=1;
			if(temnode[ia]->type!=FF&&temnode[ia]->type!=PO){
				node1[Node1Num]=temnode[ia];
				Node1Num++;
				}
			}
		//if(stop_flag==0) fnode->fw_po_dis++;
	}

free(node1);
free(temnode);
}


void ff_forw_trace_w_cpi(FIN_NODE *ff_head)
{
	int in,ia,ib,Node1Num,Node2Num,flag,stop_flag;
 	L_NODE *fnode,*fnode1,*fnode2,**node1,**temnode;
 	FIN_NODE *finnode,*fanoutlst;
	int width[MaxLevel+1],tmp_width;
node1 = (L_NODE **)calloc(numgate+2, sizeof(L_NODE *));
temnode=(L_NODE **)calloc(numgate+2, sizeof(L_NODE *));

if(node1 == NULL)     printf("memory error @node1\n"), exit(1);
if(temnode == NULL)    printf("memory error @temnode\n"), exit(1);

printf("ffnum=%d gate_num=%d\n",ffnum,numgate);

  	finnode=ff_head;
//search the faults observed by each FF

  for(in=0;finnode!=NULL;finnode=finnode->next,in++){
	Node1Num=0;
	for(ia=0;ia<numgate;ia++)
		node1[ia]=NULL;
	for(ia=0;ia<=MaxLevel;ia++)
		width[ia]=0;
	fnode=finnode->node;
	node1[0]=fnode;
	Node1Num=1;
	fnode->fw_branch=0;
	fnode->fw_depth=0;
	fnode->fw_width=0;
	fnode->fw_po_dis=0;
	stop_flag=0;//fwtracing stop point when a Po or FF is found;
	for(ia=0;ia<ffnum;ia++)
		fnode->ff_out_path[ia]=0;

		fnode->fix_gt_0=0; //for fix gates computing
	  fnode->fix_gt_1=0; //for fix gates computing

	while(Node1Num>0){

		Node2Num=0;

		if(fnode==node1[0]){
			fnode->eval_C[5]=0;
			fnode->eval_C[6]=0;
			}
		else {
		fnode->eval_C[6]++;
		fnode->eval_C[5]+=Node1Num;
			}
		for(ia=0;ia<numgate;ia++)temnode[ia]=NULL;
///////////////////////////////////////////////////////////////////////////////
		for(ia=0;ia<Node1Num;ia++){
			fnode1=node1[ia];
			width[fnode1->level]++;
			//printf("fnode1: %d %d %d \n",fnode1->line,fnode1->type,fnode1->level);
			if(fnode1->nfout>1) fnode->fw_branch+=fnode1->nfout;

			if(fnode1==fnode) {
				//fnode1->fix0=1;
			 // fnode1->fix1=1;
				 fnode->fix_gt_0=0;
				 fnode->fix_gt_1=0;
			 }

			fanoutlst=fnode1->foutlst;
			for(;fanoutlst!=NULL;fanoutlst=fanoutlst->next){
				fnode2=fanoutlst->node;
			//printf("%d %d %d \n",fnode2->line,fnode2->type,fnode2->level);

				//if(fnode2==fnode) continue;
			fix_gt_check(fnode,fnode1,fnode2);

			if(fnode2->fix0)   fnode->fix_gt_0++;
			if(fnode2->fix1)   fnode->fix_gt_1++;

				flag=0;
				for(ib=0;ib<Node2Num;ib++){
					if(temnode[ib]==fnode2){
						flag=1;break;
							}
						}
				if(flag==0){
					temnode[Node2Num]=fnode2;
					Node2Num++;
					}
				}
			}

////////////////////////////////////////////////////////////////////////////

	for(ia=0;ia<numgate;ia++) node1[ia]=NULL;
	Node1Num=0;

/*		printf("level_width= ");
	for(ia=0;ia<=MaxLevel;ia++)
		printf("%d ",width[ia]);
	printf("\n");
*/

	for(ia=0;ia<Node2Num;ia++){
			if(temnode[ia]->type==PO)
				stop_flag=1;
			if(temnode[ia]->type==FF){

				fnode->ff_out_path[fnode->eval_C[4]]=temnode[ia]->line;
				fnode->eval_C[4]++;
#if Debug
				if(fnode->line==temnode[ia]->line)
printf("FF%d: %d %d %d \n",fnode->line, temnode[ia]->type, temnode[ia]->line,fnode->eval_C[4]);//exit(1);
//printf("CPI candinate #%d, fix0=%d fix1=%d\n",fnode->line,fnode->fix_gt_0,fnode->fix_gt_1);
#endif
			}
			if(temnode[ia]->type!=FF&&temnode[ia]->type!=PO){
  #if NODE_REC
					flag=0;
				for(ib=0;ib<fnode->fw_traced_node_num;ib++){
					if(temnode[ia]==fnode->fw_traced_node[ib]){
							flag=1; break;
							}
						}
				if(flag==1) continue;

				if(temnode[ia]->level>=fnode->fw_depth) fnode->fw_depth=temnode[ia]->level;
				fnode->fw_traced_node[fnode->fw_traced_node_num] = temnode[ia];
				fnode->fw_traced_node_num++;
				//printf("%d %d %d hehre?\n",Node2Num,fnode->fw_traced_node_num,temnode[ia]->level);
				//fnode->fw_gt_list[0]++;
				//fnode->fw_gt_list[fnode->fw_gt_list[0]]=temnode[ia]->line;
#endif
				node1[Node1Num]=temnode[ia];
				Node1Num++;
				}
			}
		if(stop_flag==0) fnode->fw_po_dis++;
////////////////////////////////////////////////////////////////////////////
	}

	//fnode->fw_width=0;
	for(ia=0;ia<=MaxLevel;ia++)
		if(width[ia]>=fnode->fw_width) fnode->fw_width=width[ia];

	//if(Node2Num>=fnode->fw_width) fnode->fw_width=Node2Num;
//exit(1);

#if Debug
//if(fnode->line==4951)
printf("After Node %d Value %d %d %d %d %d %d %d \n",fnode->line,fnode->eval_C[1],fnode->eval_C[2],fnode->eval_C[3],fnode->eval_C[4],fnode->eval_C[5],fnode->eval_C[6],fnode->eval_C[7]);
printf("CPI candinate #%d, fix0=%d fix1=%d\n",fnode->line,fnode->fix_gt_0,fnode->fix_gt_1);
#endif
}
free(node1);
free(temnode);
}
