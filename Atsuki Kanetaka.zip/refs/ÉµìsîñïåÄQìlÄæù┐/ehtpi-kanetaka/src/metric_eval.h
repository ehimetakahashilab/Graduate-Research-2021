//functions for test cost and fault coverage estimation computing
//cost_cal.c, fc_exp.c
#ifndef __METRIC_EVAL_H__
#define __METRIC_EVAL_H__

#include "tpi_def.h"
#define PT 1000
#define ACAC 0.0000000000000001
#define PRINT 1
#define OFFSET 10000

long long int cost_func_cal();
double exp_fc_cal_per_pat(int patnum);

#endif
