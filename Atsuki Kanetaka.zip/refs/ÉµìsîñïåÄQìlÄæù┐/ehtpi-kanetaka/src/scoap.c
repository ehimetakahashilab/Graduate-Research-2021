//- C File ------------------------------------------------------------
//
//  File Name    [Computation.c]
//
//  System Name  [ff_sel]
//
//  Module Name  [FF_EVAL]
//
//  Author       [Senling Wang]
//
//  Affiliation  [Ehime University]
//
//  Date         [2013]
//
//  Revision     [2016.4.1]
//
//----------------------------------------------------------------------


////////////////////////////////////////////////////////////////////////
//  INCLUDE & MACRO
////////////////////////////////////////////////////////////////////////

#include"cop.h"

//MACROs:
//COPcomputation_C(Cycle), SCOAPcomputation_C(Cycle),
//COP_CO(Cycle), SCOAP_CO(Cycle),
//op_backtrace(argv,finnode,faultnum)


////////////////////////////////////////////////////////////////////////
//  VARIABLE & FUNCTION DECLARATIONS
////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////
/// FUNCTION DEFINITIONS
////////////////////////////////////////////////////////////////////////


void SCOAP_C(int Cycle)		//compute the controllability value for SCOAP method

{
  L_NODE *fnode;
  FIN_NODE *finnode;
	int ia;
long int Temp, Temple;
ia=0;
while(ia<=MaxLevel){
 fnode=gnode.next;
  for( ;fnode!=NULL;fnode=fnode->next){
if(fnode->level!=ia) continue;
    finnode=fnode->finlst;
	Temp=0;Temple=MUGEN;
    for( ;finnode!=NULL;finnode=finnode->next){
      switch(fnode->type)
	{
	case AND:
		Temp+=finnode->node->CC1[Cycle];
		if(Temple>finnode->node->CC0[Cycle])Temple=finnode->node->CC0[Cycle];
		fnode->CC0[Cycle]=Temple;
		fnode->CC1[Cycle]=Temp;
		break;
	case NAND:
		Temp+=finnode->node->CC1[Cycle];
		if(Temple>finnode->node->CC0[Cycle])Temple=finnode->node->CC0[Cycle];
		fnode->CC0[Cycle]=Temp;
		fnode->CC1[Cycle]=Temple;
		break;
	case OR:
		Temp+=finnode->node->CC0[Cycle];
		if(Temple>finnode->node->CC1[Cycle])Temple=finnode->node->CC1[Cycle];
		fnode->CC0[Cycle]=Temp;
		fnode->CC1[Cycle]=Temple;
		break;
	case NOR:
		Temp+=finnode->node->CC0[Cycle];
		if(Temple>finnode->node->CC1[Cycle])Temple=finnode->node->CC1[Cycle];
		fnode->CC0[Cycle]=Temple;
		fnode->CC1[Cycle]=Temp;
		break;
	case NOT:
		fnode->CC0[Cycle]=finnode->node->CC1[Cycle];
		fnode->CC1[Cycle]=finnode->node->CC0[Cycle];
		break;
		case FAN:
			fnode->CC0[Cycle]=finnode->node->CC0[Cycle];
			fnode->CC1[Cycle]=finnode->node->CC1[Cycle];
			break;
	//case PO:
	//	fnode->CC0[Cycle]=finnode->node->CC0[Cycle];
	//	fnode->CC1[Cycle]=finnode->node->CC1[Cycle];
	//	break;
	default:
	  printf(" error type %d -284-\n",fnode->type);

	  exit(1);
	}
    }
		fnode->CC0[Cycle]++;
		fnode->CC1[Cycle]++;

	}
ia++;
}

  finnode=ffnode.next;
  for(; finnode!=NULL; finnode=finnode->next){
    fnode=finnode->node;
	fnode->CC1[Cycle+1]=fnode->finlst->node->CC1[Cycle]+1;
	fnode->CC0[Cycle+1]=fnode->finlst->node->CC0[Cycle]+1;
  	}
	fnode=gnode.next;
  for( ;fnode!=NULL;fnode=fnode->next){
if(fnode->type!=PO) continue;
if(fnode->finlst->node->type==FF){
	fnode->CC1[Cycle]=fnode->finlst->node->CC1[Cycle+1];
	fnode->CC0[Cycle]=fnode->finlst->node->CC0[Cycle+1];
	}
else{
	fnode->CC1[Cycle]=fnode->finlst->node->CC1[Cycle];
	fnode->CC0[Cycle]=fnode->finlst->node->CC0[Cycle];
	}
}
}

void SCOAP_O(int Cycle)		//compute the observability value for SCOAP method

{
	int ia,ib;
 	L_NODE *fnode,*fnode1,*fnode2;
 	FIN_NODE *finnode,*finnode1,*foutnode;
	long int Temple;
  finnode=ffnode.next;
  for(; finnode!=NULL; finnode=finnode->next){
    fnode=finnode->node;
    finnode1=fnode->finlst;
    //finnode1->node->fanCO[Cycle][0]=fnode->CO[Cycle];
if(Cycle==Cap)    finnode1->node->fanCO[Cycle][finnode1->node->COfanNum[Cycle]]=0;
else    finnode1->node->fanCO[Cycle][finnode1->node->COfanNum[Cycle]]=fnode->CO[Cycle];
	finnode1->node->COfanNum[Cycle]++;
	}
	fnode=gnode.next;
	for(;fnode!=NULL;fnode=fnode->next){
		if(fnode->type==PO) continue;
		foutnode=fnode->foutlst;
		//printf("%d: ",fnode->nfout);

/*include PO or disinclude PO*/
#if REMOVEPO
		if(fnode->nfout==1&&foutnode->node->type==PO){
		 fnode->fanCO[Cycle][fnode->COfanNum[Cycle]]=0;
		 fnode->COfanNum[Cycle]++;
			}
#else
	for(;foutnode!=NULL;foutnode=foutnode->next){
		if(foutnode->node->type==PO){
			//printf(" here");
		 fnode->fanCO[Cycle][fnode->COfanNum[Cycle]]=0;
		 fnode->COfanNum[Cycle]++;
			}
			}//printf("\n");
#endif

		}
	ia=MaxLevel;
while(ia>0){
	fnode=gnode.next;
	for(;fnode!=NULL;fnode=fnode->next){
		if(fnode->level!=ia||fnode->type==PO) continue;

		if(fnode->type!=PO){
		Temple=fnode->fanCO[Cycle][0];
		for(ib=1;ib<fnode->COfanNum[Cycle];ib++)
		if(Temple>fnode->fanCO[Cycle][ib])Temple=fnode->fanCO[Cycle][ib];
		fnode->CO[Cycle]=Temple;
			}

		finnode=fnode->finlst;
		for(;finnode!=NULL;finnode=finnode->next){
			fnode1=finnode->node;
			fnode1->fanCO[Cycle][fnode1->COfanNum[Cycle]]=1;
			//if(fnode1->type==FF) printf("FF ");
			finnode1=fnode->finlst;
			for(;finnode1!=NULL;finnode1=finnode1->next){
				fnode2=finnode1->node;
				if(fnode1==fnode2) continue;
			switch(fnode->type){
				case AND:
				case NAND:

					fnode1->fanCO[Cycle][fnode1->COfanNum[Cycle]]+=fnode2->CC1[Cycle-1];
					break;
				case OR:
				case NOR:
					fnode1->fanCO[Cycle][fnode1->COfanNum[Cycle]]+=fnode2->CC0[Cycle-1];
					break;
				case NOT:
					fnode1->fanCO[Cycle][fnode1->COfanNum[Cycle]]=1;
					break;
				//case PO:
				//	fnode1->fanCO[Cycle][fnode1->COfanNum[Cycle]]*=fnode->O[Cycle];
				break;
				default:
					printf("error102: unsupported gate\n"),exit(1);
					}
				}
			fnode1->fanCO[Cycle][fnode1->COfanNum[Cycle]]+=fnode->CO[Cycle];
			fnode1->COfanNum[Cycle]++;
				}

			}
		//}
		ia--;
	}

  finnode=ffnode.next;
  for(; finnode!=NULL; finnode=finnode->next){
    fnode=finnode->node;
	Temple=fnode->fanCO[Cycle][0];
		for(ib=1;ib<fnode->COfanNum[Cycle];ib++)
		if(Temple>fnode->fanCO[Cycle][ib])Temple=fnode->fanCO[Cycle][ib];
		fnode->CO[Cycle-1]=Temple;
		}

  finnode=pinode.next;
  for(;finnode!=NULL;finnode=finnode->next){
    fnode=finnode->node;

	Temple=fnode->fanCO[Cycle][0];
		for(ib=1;ib<fnode->COfanNum[Cycle];ib++)
		if(Temple>fnode->fanCO[Cycle][ib])Temple=fnode->fanCO[Cycle][ib];
		fnode->CO[Cycle-1]=Temple;
		}

}
