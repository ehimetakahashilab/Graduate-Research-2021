////////////////////////////////////////////////////////////////////////
//  INCLUDE & MACRO
////////////////////////////////////////////////////////////////////////

#include"cop.h"

void COP_O(int Cycle)		//compute the observability value for COP method
{
	int ia,ib;
 	L_NODE *fnode,*fnode1,*fnode2;
 	FIN_NODE *finnode,*fanin_node,*foutnode;
	double Temple;


  finnode=ffnode.next;
  for(; finnode!=NULL; finnode=finnode->next){
    fnode=finnode->node;
		if(Cycle == Cap || fnode->op_flag ){
			fnode->O[Cycle]=1.0;
		}
	}
	finnode=ffnode.next;
	for(; finnode!=NULL; finnode=finnode->next){
		fnode=finnode->node;
			fnode->fanNum[Cycle]=0;
		foutnode=fnode->foutlst;
		for (; foutnode != NULL; foutnode = foutnode->next) {

			if (foutnode->node->type == PO) {
				if(Cycle == Cap || fnode->op_flag){
						fnode->fanO[Cycle][fnode->fanNum[Cycle]] = 1.0;

							}
					else {
							fnode->fanO[Cycle][fnode->fanNum[Cycle]] = 0.0;
						}
						fnode->fanNum[Cycle]++;
			}
			else if(foutnode->node->type == FF ){
			//	printf("fnode= %d \n",fnode->line);
				if(Cycle == Cap|| fnode->op_flag ){
						fnode->fanO[Cycle][fnode->fanNum[Cycle]] = 1.0;
						fnode->fanNum[Cycle]++;

							}
					else {
							fnode->fanO[Cycle][fnode->fanNum[Cycle]] = foutnode->node->O[Cycle];
							fnode->fanNum[Cycle]++;
						}
					}
			}
	}
	finnode=pinode.next;
	for(;finnode!=NULL;finnode=finnode->next){
		fnode=finnode->node;
			fnode->fanNum[Cycle]=0;
	}
	fnode=gnode.next;
	for(;fnode!=NULL;fnode=fnode->next){
		if(fnode->type==PO) {		fnode->fanNum[Cycle]=0; continue;}
		foutnode=fnode->foutlst;

		fnode->fanNum[Cycle]=0;
//	  fnode->fanNum[Cycle]=fnode->nfout;
		#if REMOVEPO
		    for (; foutnode != NULL; foutnode = foutnode->next) {
					if (foutnode->node->type == PO) {
		        fnode->fanO[Cycle][fnode->fanNum[Cycle]] = 0.0;
		        fnode->fanNum[Cycle]++;
					}
					else if(foutnode->node->type == FF ){
					//	printf("fnode= %d \n",fnode->line);
						if(Cycle == Cap || foutnode->node->op_flag ){
		      			fnode->fanO[Cycle][fnode->fanNum[Cycle]] = 1.0;
							  fnode->fanNum[Cycle]++;
									}
							else {
									fnode->fanO[Cycle][fnode->fanNum[Cycle]] = foutnode->node->O[Cycle];
									fnode->fanNum[Cycle]++;
								}
							}
					}
		#else
		    for (; foutnode != NULL; foutnode = foutnode->next) {
		      if (foutnode->node->type == PO) {
		        fnode->fanO[Cycle][fnode->fanNum[Cycle]] = 1.0;
		        fnode->fanNum[Cycle]++;
					}
					else if(foutnode->node->type == FF ){
						if(Cycle == Cap || foutnode->node->op_flag ){
		      			fnode->fanO[Cycle][fnode->fanNum[Cycle]] = 1.0;
							  fnode->fanNum[Cycle]++;
									}
							else {
									fnode->fanO[Cycle][fnode->fanNum[Cycle]] = foutnode->node->O[Cycle];
									fnode->fanNum[Cycle]++;
								}
							}
		    }
		#endif

		}
/*if(Cycle==4){
		finnode=ffnode.next;
	  for(; finnode!=NULL; finnode=finnode->next){
	    fnode=finnode->node;
			printf("[%d %d %f %d %d] \n",fnode->line,fnode->nfout,fnode->O[Cycle],fnode->fanNum[Cycle],Cycle);
}
}
*/
//exit(1);
	ia=MaxLevel;
while(ia>=0){
	fnode=gnode.next;
	for(;fnode!=NULL;fnode=fnode->next){
		if(fnode->level!=ia||fnode->type==PO) continue;

		if(fnode->fanNum[Cycle]>=1){
		Temple=1.0;
		for(ib=0;ib<fnode->fanNum[Cycle];ib++){
		Temple*=(1-fnode->fanO[Cycle][ib]);
	}
		fnode->O[Cycle]=1-Temple;
			}
		else fnode->O[Cycle]=fnode->fanO[Cycle][0];

		if(fnode->fanNum[Cycle]>100) {//exit(1);
			printf("[%d %d %f %d] ",fnode->line,fnode->nfout,fnode->O[Cycle],fnode->fanNum[Cycle]);
exit(1);
}
		finnode=fnode->finlst;
		for(;finnode!=NULL;finnode=finnode->next){
			fnode1=finnode->node;
			fnode1->fanO[Cycle][fnode1->fanNum[Cycle]]=1.0;
			fanin_node=fnode->finlst;
			for(;fanin_node!=NULL;fanin_node=fanin_node->next){
				fnode2=fanin_node->node;
				if(fnode1==fnode2) continue;
				switch (fnode->type) {
					case AND:
					case NAND:
						fnode1->fanO[Cycle][fnode1->fanNum[Cycle]] *= fnode2->C1[Cycle - 1];
						break;
					case OR:
					case NOR:
						fnode1->fanO[Cycle][fnode1->fanNum[Cycle]] *=	fnode2->C0[Cycle - 1];
						break;
					case NOT:
					case XOR:
					case XNOR:
					case FAN:
						fnode1->fanO[Cycle][fnode1->fanNum[Cycle]] = 1.0;
						break;

						// case PO:
						//	fnode1->fanO[Cycle][fnode1->fanNum[Cycle]]*=fnode->O[Cycle];
				//		break;
				default:
					printf("error102: unsupported gate\n"),exit(1);
					}
				}
			fnode1->fanO[Cycle][fnode1->fanNum[Cycle]]*=fnode->O[Cycle];
			fnode1->fanNum[Cycle]++;
				}



	//					if(fnode->type!=PO){

					//if(Cycle==Cap) 		fnode->O[Cap+2]=0;//サイクルごとのCを記録し、後で平均をとる。
					 //fnode->O[Cap+2]+=fnode->O[Cycle];//サイクルごとのＯを記録し、後で平均をとる。
//				 		}


		if(Cycle==Cap) 		fnode->O[Cap+2]=0.0;//サイクルごとのCを記録し、後で平均をとる。
		 fnode->O[Cap+2]+=fnode->O[Cycle];//サイクルごとのＯを記録し、後で平均をとる。
	//	 if(fnode->line==3399)
		// 	printf("[%d,%d-> %f] ",Cycle, fnode->line,fnode->O[Cycle]);


			}
		ia--;
	}
//exit(1);

  finnode=ffnode.next;
  for(; finnode!=NULL; finnode=finnode->next){
    fnode=finnode->node;
	//if(fnode->finlst->node->type==FF)printf("adjacent FF %d->%d \n",fnode->finlst->node->line,fnode->line);
/*foutnode=fnode->foutlst;
		printf("%d: ",fnode->nfout);
		for(;foutnode!=NULL;foutnode=foutnode->next)
			printf("%d ",foutnode->node->type);
		printf("\n");*/
	//	printf("~|%d %f %d|~: ",fnode->line,fnode->O[Cycle],Cycle);
#if FF_EXCLUDE
		if(fnode->op_flag) fnode->O[Cycle-1]=1.0;
		else{
		if(fnode->fanNum[Cycle]>=1){
		Temple=1.0;
		for(ib=0;ib<fnode->fanNum[Cycle];ib++)
		Temple*=(1-fnode->fanO[Cycle][ib]);
		fnode->O[Cycle-1]=1-Temple;
			}
		else fnode->O[Cycle-1]=fnode->fanO[Cycle][0];
	}
#else
	if(fnode->op_flag) fnode->O[Cycle-1]=1.0;
	else{
		if(fnode->fanNum[Cycle]>=1){
		Temple=1.0;
		for(ib=0;ib<fnode->fanNum[Cycle];ib++)
		Temple*=(1-fnode->fanO[Cycle][ib]);
		fnode->O[Cycle-1]=1-Temple;
			}
		else fnode->O[Cycle-1]=fnode->fanO[Cycle][0];
	}
#endif
//	printf("[%d %d %f %d @%d] \n",fnode->line,fnode->nfout,fnode->O[Cycle-1],fnode->fanNum[Cycle],Cycle);
		}
/*		if(Cycle==4){
				finnode=ffnode.next;
			  for(; finnode!=NULL; finnode=finnode->next){
			    fnode=finnode->node;
					printf("[%d %d %f %d %d] \n",fnode->line,fnode->nfout,fnode->O[Cycle],fnode->fanNum[Cycle],Cycle);
		}
		}
		*/
		//printf("\n");
//exit(1);
  finnode=pinode.next;
  for(;finnode!=NULL;finnode=finnode->next){
    fnode=finnode->node;
		if(fnode->fanNum[Cycle]>=1){
		Temple=1.0;
		for(ib=0;ib<fnode->fanNum[Cycle];ib++)
		Temple*=(1-fnode->fanO[Cycle][ib]);
		fnode->O[Cycle-1]=1-Temple;
			}
		else fnode->O[Cycle-1]=fnode->fanO[Cycle][0];
		}

//if(Cycle==Cap-2) exit(1);

//	fnode=gnode.next;
//	for(;fnode!=NULL;fnode=fnode->next){
//	if(fnode->line == 1390)
	//	printf("~|%d %f %d|~: \n",fnode->line,fnode->O[Cycle-1],Cycle);

//}			//printf("\n");
//if(Cycle==Cap) exit(1);
//exit(1);
}
