#include "circuit.h"
#define NALLOC (L_NODE *)malloc(sizeof(L_NODE))
#define FALLOC (FLT_NODE *)malloc(sizeof(FLT_NODE ))
#define INALLOC (FIN_NODE *)malloc(sizeof(FIN_NODE))

ELEMENT *gate;
int *pitbl,*potbl,*fftbl,*ffintbl,*flist;

void make_line_list(char *argv[10])
{
  L_NODE *fnode,*head_node,*end_node,**address;
  FIN_NODE *finnode,*head_fin;
  int ni,fil,line,fin,fol;

int count2=0;
printf("read circuit %d\n",lpnt);
  readf(argv);

printf("read finish %d\n",lpnt);
  address = (L_NODE **)calloc(lpnt+1, sizeof(L_NODE *));

  if(address == NULL)
    printf("memory error @make_line_list\n"), exit(1);

  head_node=NULL;end_node=NULL;
  for(ni=lpnt;ni>=1;ni--){
  if(gate[ni].type==FAN)
  continue;

    if(NULL==(fnode=NALLOC))
      printf(" error -984-\n"),exit(1);
	//count2++;
    address[ni]=fnode;
    fnode->line=ni;
    fnode->type=gate[ni].type;
    fnode->next=head_node;

    if(head_node!=NULL)
      head_node->prev=fnode;
    head_node=fnode;
	if(end_node==NULL) end_node=fnode;
  }
//printf("%d ",count2);exit(1);
  for(ni=1;ni<=lpnt;ni++){
    if(gate[ni].type==FAN){
      fil=gate[ni].fil;
      address[ni]=address[fil];
    }
  }
printf("  /** make fan-in list begin **/ \n");
  fnode=head_node;
  for( ;fnode!=NULL;fnode=fnode->next){
    line=fnode->line;
    /*** make fan-in lists ***/
    fil=gate[line].fil;
    if(gate[line].type==PI){
      fnode->finlst=NULL;
	fnode->nfin=0;
    }
    else if(gate[line].nfi==1){

      if(NULL==(finnode=INALLOC))
	printf(" error -239-\n"), exit(1);
/*
      finnode=fin_tmp+(fill_fin_tmp++);
*/
      finnode->node=address[fil];
      finnode->next=NULL;
      fnode->finlst=finnode;
	fnode->nfin=1;
    }
    else{
      head_fin=NULL;
      for(ni=0;ni<gate[line].nfi;ni++){
	fin=flist[ni+fil];

	if(NULL==(finnode=INALLOC))
	  printf(" error -233-\n"), exit(1);
/*
        finnode=fin_tmp+(fill_fin_tmp++);
*/
	finnode->node=address[fin];
	finnode->next=head_fin;
	head_fin=finnode;
      }
	fnode->nfin=gate[line].nfi;
      fnode->finlst=head_fin;
    }

  }
printf("  /** make fan-in list end **/ \n");
printf("  /** make fan-out list begin **/ \n");

  for(ni=1;ni<=lpnt;ni++){
    if(gate[ni].type==FAN){
      fol=gate[ni].fol;
      address[ni]=address[fol];
    }
  }
  fnode=head_node;
  for( ;fnode!=NULL;fnode=fnode->next){
    line=fnode->line;
//    fnode->fltList[0]=0;
//    fnode->flttyp[0]=0;
    //  if(line==42)  printf(" Line = %d \n",line);

    /*** make fan-out lists ***/
    fol=gate[line].fol;
    if(gate[line].type==PO){
      fnode->foutlst=NULL;
	fnode->nfout=0;
    }
    else if(gate[line].nfo==1){

      if(NULL==(finnode=INALLOC))
	printf(" error -239-\n"), exit(1);
/*
      finnode=fin_tmp+(fill_fin_tmp++);
*/
      finnode->node=address[fol];
      finnode->next=NULL;
      fnode->foutlst=finnode;
	fnode->nfout=1;
    }
    else{
      head_fin=NULL;
      for(ni=0;ni<gate[line].nfo;ni++){
	fin=flist[ni+fol];

	if(NULL==(finnode=INALLOC))
	  printf(" error -233-\n"), exit(1);

	finnode->node=address[fin];
	finnode->next=head_fin;
	head_fin=finnode;
      }
      fnode->foutlst=head_fin;
	fnode->nfout=ni;
    }

  }

printf("  /** make fan-out list end **/ \n");

  head_fin=&pinode;
  for(ni=1;ni<=inpnum;ni++){
    line=pitbl[ni];

    if(NULL==(finnode=INALLOC))
      printf(" error -259-\n"), exit(1);
/*
    finnode=fin_tmp+(fill_fin_tmp++);
*/
    finnode->node=address[line];
    head_fin->next=finnode;
    head_fin=finnode;
  }
  head_fin->next=NULL;

  head_fin=&ffnode;
  for(ni=1;ni<=ffnum;ni++){
    line=fftbl[ni];
    if(NULL==(finnode=INALLOC))
      printf(" error -259-\n"), exit(1);
/*
    finnode=fin_tmp+(fill_fin_tmp++);
*/
    finnode->node=address[line];
    head_fin->next=finnode;
    head_fin=finnode;
  }
  head_fin->next=NULL;

  head_fin=NULL;
  for(ni=numout;ni>=1;ni--){
    line=gate[potbl[ni]].fol;
    if(NULL==(finnode=INALLOC))
      printf(" error -259-\n"), exit(1);
/*
    finnode=fin_tmp+(fill_fin_tmp++);
*/
    finnode->node=address[line];
    finnode->next=head_fin;
    head_fin=finnode;
  }
  ponode.next=head_fin;
  gnode.next=head_node;
  gnode.last=end_node;
  head_node->prev=&gnode;

  make_fault_list(address);
printf("  /** make fault list end **/ \n");
  free(gate);
  free(flist);
  free(pitbl);
  free(potbl);
  free(fftbl);
  free(ffintbl);

}

void make_fault_list(L_NODE **address)

{
  FIN_NODE *finnode,*head_fin;
  FLT_NODE *head_flt,*flttag;
  int ni,saval,fil,fol;
printf("  /** make fault list begin **/ \n");
  /** make fault list **/
  head_flt=&fltlst;
  sum_flt=0;


  for(ni=1;ni<=lpnt;ni++){

/*     if(ni<=250 || ni>=300) */
/*       continue; */

    fol=gate[ni].fol;
/*    if(gate[ni].nfo==1 && gate[fol].type==PO || gate[ni].type==PO) */
    if(gate[ni].type==PO)
      continue;
    if(gate[ni].nfo==1 && gate[fol].type!=FF && gate[fol].type!=PO){
      switch(gate[fol].type)
	{
	case AND:
	case NAND:
	  saval=1;
	  break;
	case OR:
	case NOR:
	  saval=0;
	  break;
	case NOT:
	  continue;
	default:
	  printf(" ni = %d %d %d error -9183-\n",ni,fol,gate[fol].type), exit(1);
	}
      if(NULL==(flttag=FALLOC))
	printf(" ni = %d error -639-\n",ni), exit(1);
/***
      flttag=(fltlst_tmp+sum_flt);
***/
      sum_flt++;
	flttag->num=sum_flt;
      if(sum_flt>=MAXFLT)
	printf(" error 19485 sumflt = %d\n",sum_flt), exit(1);

      if(gate[ni].type==FAN)
	flttag->back=address[ gate[ni].fil ];
      else
	flttag->back=address[ni];
      flttag->forwd=address[fol];

      flttag->saval=saval;

      flttag->prev=head_flt;
      head_flt->next=flttag;
      head_flt=flttag;
    }

    else if(gate[ni].nfo==1){ /** gate[fol].type==FF or PO **/

      for(saval=0;saval<2;saval++){
	if(NULL==(flttag=FALLOC))
	  printf(" error -639-\n"), exit(1);

/***
	flttag=(fltlst_tmp+sum_flt);
***/
	sum_flt++;
		flttag->num=sum_flt;
	if(sum_flt>=MAXFLT)
	  printf(" error 19486 sumflt = %d\n",sum_flt), exit(1);

	if(gate[ni].type!=FAN)
	  flttag->back=address[ ni ];
	else
	  flttag->back=address[gate[ni].fil];
	flttag->forwd=address[fol];
        flttag->saval=saval;

	flttag->prev=head_flt;
	head_flt->next=flttag;
	head_flt=flttag;
      }
    }
    else{
      for(saval=0;saval<2;saval++){
	if(NULL==(flttag=FALLOC))
	  printf(" error -639-\n"), exit(1);
/***
	flttag=(fltlst_tmp+sum_flt);
***/
	sum_flt++;
	flttag->num=sum_flt;
	if(sum_flt>=MAXFLT)
	  printf(" error 19487 sumflt = %d\n",sum_flt), exit(1);
	flttag->back=address[ni];
	flttag->forwd=NULL;
        flttag->saval=saval;

	flttag->prev=head_flt;
	head_flt->next=flttag;
	head_flt=flttag;
      }
    }
  }
  head_flt->next=NULL;
#if DEBUG3
  prn_fltlst(fltlst.next);
#endif
//exit(1);

}

void sort_node()
{
  L_NODE *fnode,*new_head,*target,*last_node;
  FIN_NODE *finnode;
  int ni,line,fil,fincheck[lpnt*2];
printf("  /** sort nodes begin **/ \n");
  for(ni=1;ni<=lpnt;ni++)
    fincheck[ni]=0;
  new_head=NULL;

  /** extract FF nodes **/
    finnode=ffnode.next;
    for( ;finnode!=NULL;finnode=finnode->next){
      fnode=finnode->node;
      if(fnode->next!=NULL)
	fnode->next->prev=fnode->prev;
      fnode->prev->next=fnode->next;
      fnode->next=new_head;
      new_head=fnode;
      fincheck[fnode->line]=1;
    }
  last_node=ffnode.next->node;
  /** extract PI nodes **/
    finnode=pinode.next;
    for( ;finnode!=NULL;finnode=finnode->next){
      fnode=finnode->node;
      if(fnode->next!=NULL)
	fnode->next->prev=fnode->prev;
      fnode->prev->next=fnode->next;
      fnode->next=new_head;
      new_head=fnode;
      fincheck[fnode->line]=1;
    }
  inode.next=new_head;


#if DEBUG3
  prn_node(new_head); /** print PI & FF nodes list **/
  prn_node(gnode.next); /** print the other nodes list **/
#endif
  new_head=NULL;

  while(gnode.next!=NULL){
    fnode=gnode.next;
    for( ;fnode!=NULL; ){
      if(fin_check(fnode->finlst,fincheck)==TRUE){

	target=fnode;
	fnode=fnode->next;
	if(target->next!=NULL)
	  target->next->prev=target->prev;
	target->prev->next=target->next;
	target->next=new_head;
	new_head=target;
//printf("gate node=%d\n",target->line);
	fincheck[target->line]=1;

      }
      else{
	//printf("check=false1_%d %d\n",fnode->line,fnode->type);
	fnode=fnode->next;
	//printf("check=false2_%d %d\n",fnode->line,fnode->type);
	}
    }
  }

//printf("gate node loop check end\n");
#if DEBUG3
  prn_node(new_head);
#endif
  /** reverse order **/
  fnode=new_head;
  new_head=NULL;
  for( ;fnode!=NULL; ){
    target=fnode;
    fnode=fnode->next;
    target->next=new_head;
    target->prev=fnode;
    new_head=target;
  }
/** exclude PI & FF nodes **/
  new_head->prev=&gnode;
  gnode.next=new_head;

/** include PI & FF nodes **
  last_node->next=new_head;
  new_head->prev=last_node;
  gnode.next=inode.next;
  inode.next->pre=&gnode;
**/

#if DEBUG3
  prn_node(gnode.next);
#endif
}

_Bool fin_check(FIN_NODE *finnode, int fincheck[])
{
  for( ;finnode!=NULL;finnode=finnode->next){
    if(fincheck[finnode->node->line]==0)
      break;
  }
  if(finnode==NULL)
    return TRUE;
  else
    return FALSE;
}


void readf(char *argv[9])
{
	int i,j;
	FILE *fp;
	char name[150];
	if(NULL==(fp=fopen(argv[1],"r"))){
		printf("There is not such a file(%s).\n",argv[1]);exit(2);
		}

	fscanf(fp,"%d%d%d%d%d%d",&lpnt,&numout,&inpnum,&slist,&ffnum,&numgate);

#if FFNAME
FILE *ffname_fp;
char ff_path[100];
//if(getcwd(ff_path, 50)==NULL) printf("concurrent path failure\n"),exit(1);

sprintf(ff_path,"%s/%s_OSK_FFINFO",argv[2],argv[1]);

if(NULL==(ffname_fp=fopen(ff_path,"w"))){
	printf("There is not such a file(%s).\n",argv[1]);exit(2);
	}
#endif


       gate = (ELEMENT *)calloc(lpnt+1, sizeof(ELEMENT));
       flist = (int *)calloc(slist+1, sizeof(int));
       pitbl = (int *)calloc(inpnum+1 ,sizeof(int));
       potbl = (int *)calloc(numout+1 ,sizeof(int));
       fftbl = (int *)calloc(ffnum+1 ,sizeof(int));
       ffintbl = (int *)calloc(ffnum+1 ,sizeof(int));

       if((gate == NULL)||(flist == NULL)||(pitbl == NULL)||(potbl == NULL)||(fftbl == NULL)||(ffintbl == NULL))
         printf("memory error @readf\n"), exit(1);

	for(i=1;i<=lpnt;i++){
		fscanf(fp,"%d",&j);
		fscanf(fp,"%d",&j);
		gate[i].type=(CHGATA)j;
		fscanf(fp,"%d",&j);
		gate[i].nfi=(CHGATA)j;
		fscanf(fp,"%d",&j);
		gate[i].fil=j;
#if NAME
		fscanf(fp,"%s",gate[i].name);
#else
#if FFNAME
		fscanf(fp,"%s",name);
	if(gate[i].type==FF){
		printf("%s  \n",name);
		fprintf(ffname_fp,"%d %s\n",i-inpnum-numout,name);
		}
#else
		fscanf(fp,"%s",name);
#endif
#endif


		fscanf(fp,"%d",&j);
		gate[i].nfo=(CHGATA)j;

		fscanf(fp,"%d",&j);
		gate[i].fol=j;
	}
	for(i=1;i<=slist;i++){
		fscanf(fp,"%d%d",&j,&j);
		flist[i]=j;
	}
#if FFNAME
	fclose(ffname_fp);
exit(1);
#endif

/* following is to make pilst[], polst[] and fflst[] in seqential circuit */
#if SEQEN
	for(i=1;i<=inpnum;i++){
		fscanf(fp,"%d%s%d",&j,name,&j);
		pitbl[ i ]=j;
	}
	for(i=1;i<=numout;i++){
		fscanf(fp,"%d%s%d",&j,name,&j);
		potbl[ i ]=j;
	}
	for(i=1;i<=ffnum;i++){
		fscanf(fp,"%d%d",&j,&j);
		fftbl[ i ]=j;
		ffintbl[ i ]=gate[j].fil;

	}

/* following in using combinational circuit */

#else
	for(i=1;i<=inpnum;i++){
		fscanf(fp,"%d%s%d",&j,name,&j);
		pitbl[ i ]=j;
	}
	for(i=1;i<=numout;i++){
		fscanf(fp,"%d%s%d",&j,name,&j);
		potbl[ i ]=j;
	}
#endif
	fclose(fp);
}




void gate_level()	//sorting the gate level for combination circuit (one time frame)
{
  L_NODE *fnode;
  FIN_NODE *finnode;
  int flag,tmplevl,gate_count=0;

  finnode=pinode.next;
  for(;finnode!=NULL;finnode=finnode->next){
    fnode=finnode->node;
 	fnode->level=0;
	fnode->levelflag=1;
	}

  finnode=ffnode.next;
  for(; finnode!=NULL; finnode=finnode->next){
    fnode=finnode->node;
 	fnode->level=0;
	fnode->levelflag=1;
  }

  fnode=gnode.next;
  for( ;fnode!=NULL;fnode=fnode->next){
	fnode->level=-200;
	fnode->levelflag=0;
	if(fnode->type!=PO)
	gate_count++;
  }
MaxLevel=0;
while(gate_count>0){
  fnode=gnode.next;
  for( ;fnode!=NULL;fnode=fnode->next){
	if(fnode->type==PO||fnode->levelflag==1) continue;
    		finnode=fnode->finlst;flag=0;
   	 for(;finnode!=NULL;finnode=finnode->next){
		if(finnode->node->levelflag==0){ flag=1;fnode->levelflag=0;break;}
		}
	if(flag==0){
		tmplevl=-1;
		finnode=fnode->finlst;
		for(;finnode!=NULL;finnode=finnode->next){
		 if(finnode->node->level>tmplevl) tmplevl=finnode->node->level;
			}
		fnode->level=tmplevl+1;
		fnode->levelflag=1;
		gate_count--;
	   if(fnode->level>MaxLevel) MaxLevel=fnode->level;
		}
	}
    }
printf("pi, po, ffnumber, max level gatenum fault number line number= %d, %d, %d,%d, %d, %d %d\n",inpnum, numout,ffnum, MaxLevel,numgate-inpnum-numout-ffnum,sum_flt,lpnt); 
}
