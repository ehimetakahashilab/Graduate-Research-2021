#include"cpi.h"
#include"time.h"


void c0_1_bias_cal(char *out_dir,char *circuit_name)
{

  time_t timer;        /* 時刻を取り出すための型（実際はunsigned long型） */
  struct tm *local;    /* tm構造体（時刻を扱う */

  /* 年月日と時分秒保存用 */
  int year, month, day, hour, minute, second;

  timer = time(NULL);        /* 現在時刻を取得 */
  local = localtime(&timer);    /* 地方時に変換 */

  /* 年月日と時分秒をtm構造体の各パラメタから変数に代入 */
  year = local->tm_year + 1900;        /* 1900年からの年数が取得されるため */
  month = local->tm_mon + 1;        /* 0を1月としているため */
  day = local->tm_mday;
  hour = local->tm_hour;
  minute = local->tm_min;
  second = local->tm_sec;

  /* 現在の日時を表示 */
  printf("%d年%d月%d日 %d時%d分%d秒です\n", year, month, day, hour, minute, second);

  printf("Initialization Begin\n");
  ini_for_testability();
//  CPI_initiallization();
  printf("Initialization End\n TestabilityComputation start\n");

  char out_path[200];
  sprintf(out_path,"%s/bias.csv",out_dir);
  //printf("\nhere?\n");
  FILE *fout;
    fout=fopen(out_path,"a");
  if(fout==NULL) {
    printf("bias file %s is not exist, creat new!\n",out_path), exit(1);
  }
    int ia=0,i_cp=0;

    printf("~Controllablity Computing start\n");
    for (ia=0; ia < Cap; ia++) {
      COP_C(ia);
    }
    printf("~Controllablity Computing End\n");
    printf("~Observability Computing start\nCap=%d\n",Cap);//exit(1);
    for(ia=Cap;ia>0;ia--){
      COP_O(ia);
      }
    printf("~Observability Computing End\n");

    L_NODE *fnode;
    FIN_NODE *finnode;
    double c1_val[Cap+1], c0_val[Cap+1], o_val[Cap+1];
    double c_variance[Cap+1],o_variance[Cap+1],bias_ave[Cap+1],c1_variance[Cap+1];
    int node_cnt=0;
    for (ia=0; ia <=Cap; ia++) {
      c1_val[ia]=0.0;
      c0_val[ia]=0.0;
      c1_variance[ia]=0.0;
      o_val[ia]=0.0;
      c_variance[ia]=0.0;
      o_variance[ia]=0.0;
      bias_ave[ia]=0.0;
    }

    fnode=gnode.next;
     for( ;fnode!=NULL;fnode=fnode->next){
        if(fnode->type==PI||fnode->type==PO) continue;
        for (ia=0; ia < Cap; ia++) {
          c1_val[ia]+=fnode->C1[ia];
          c0_val[ia]+=fnode->C0[ia];
        }
        for(ia=Cap;ia>0;ia--){
          o_val[ia]+=fnode->O[ia];
            }
        node_cnt++;
     }

     finnode=ffnode.next;
     for(; finnode!=NULL; finnode=finnode->next){
       fnode=finnode->node;
       for (ia=0; ia < Cap; ia++) {
         c1_val[ia]+=fnode->C1[ia+1];
         c0_val[ia]+=fnode->C0[ia+1];
       }
        for(ia=Cap;ia>0;ia--){
         o_val[ia]+=fnode->O[ia-1];
       //  printf("%.4f, ",fnode->O[ia]);
           }
     //    printf("\n");
       node_cnt++;
     }

for (ia=0; ia < Cap; ia++) {
bias_ave[ia]=fabs(c1_val[ia]-c0_val[ia])/node_cnt;
}

    fnode=gnode.next;
         for( ;fnode!=NULL;fnode=fnode->next){
            if(fnode->type==PI||fnode->type==PO) continue;
            for (ia=0; ia < Cap; ia++) {
              c_variance[ia]+=(fabs(fnode->C1[ia]-fnode->C0[ia])-bias_ave[ia])*(fabs(fnode->C1[ia]-fnode->C0[ia])-bias_ave[ia]);
              c1_variance[ia]+=fabs(fnode->C1[ia]-(c1_val[ia]/node_cnt))*fabs(fnode->C1[ia]-(c1_val[ia]/node_cnt));
            }

            for(ia=Cap;ia>0;ia--){
              o_variance[ia]+=(fnode->O[ia]-(o_val[ia]/node_cnt))*(fnode->O[ia]-(o_val[ia]/node_cnt));
                }
         }
  finnode=ffnode.next;
         for(; finnode!=NULL; finnode=finnode->next){
           fnode=finnode->node;
           for (ia=0; ia < Cap; ia++) {
             c_variance[ia]+=(fabs(fnode->C1[ia+1]-fnode->C0[ia+1])-bias_ave[ia])*(fabs(fnode->C1[ia+1]-fnode->C0[ia+1])-bias_ave[ia]);
              c1_variance[ia]+=fabs(fnode->C1[ia+1]-(c1_val[ia]/node_cnt))*fabs(fnode->C1[ia+1]-(c1_val[ia]/node_cnt));
           }
        for(ia=Cap;ia>0;ia--){
              o_variance[ia]+=(fnode->O[ia-1]-(o_val[ia]/node_cnt))*(fnode->O[ia-1]-(o_val[ia]/node_cnt));
           //  printf("%.4f, ",fnode->O[ia]);
               }
         //    printf("\n");
         }


  fprintf(fout,"%d年%d月%d日%d時%d分%d秒:", year, month, day, hour, minute, second);
  fprintf(fout, "%s\n", circuit_name);
  printf("%d年%d月%d日%d時%d分%d秒:", year, month, day, hour, minute, second);
  printf("%s\n", circuit_name);

  for (ia=0; ia < Cap; ia++) {
      fprintf(fout, "%.4f, ",c1_val[ia]/node_cnt);
      printf("%.4f, ",c1_val[ia]/node_cnt);
  }
  fprintf(fout, "\n");
  printf("\n");

  for (ia=0; ia < Cap; ia++) {
      fprintf(fout, "%.4f, ",sqrt(c1_variance[ia]/(node_cnt-1)));
      printf("%.4f, ",sqrt(c1_variance[ia]/(node_cnt-1)));
  }
  fprintf(fout, "\n");
  printf("\n");

/*
for (ia=0; ia < Cap; ia++) {
    fprintf(fout, "%.4f, ",bias_ave[ia]);
    printf("%.4f, ",bias_ave[ia]);

}
fprintf(fout, "\n");
printf("\n");
for (ia=0; ia < Cap; ia++) {
    fprintf(fout, "%.4f, ",sqrt(c_variance[ia]/(node_cnt-1)));
    printf("%.4f, ",sqrt(c_variance[ia]/(node_cnt-1)));

}
fprintf(fout, "\n");
printf("\n");

for (ia=1; ia <=Cap; ia++) {
    fprintf(fout, "%.4f, ",o_val[ia]/node_cnt);
    printf("%.4f, ",o_val[ia]/node_cnt);
}
fprintf(fout, "\n");
printf("\n");
for (ia=1; ia <=Cap; ia++) {
    fprintf(fout, "%.4f, ",sqrt(o_variance[ia]/(node_cnt-1)));
    printf("%.4f, ",sqrt(o_variance[ia]/(node_cnt-1)));

}*/
fprintf(fout, "\n");
printf("\n");
printf("\nbias computing end\n\n");

fclose(fout);
}
