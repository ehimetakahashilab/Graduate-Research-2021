//functions for controllability or observability computing
#ifndef __CIRCUIT_H__
#define __CIRCUIT_H__
//#pragma once
#include"tpi_def.h"

void make_line_list(char *argv[10]);
void make_fault_list(L_NODE **address);
void sort_node();
_Bool fin_check(FIN_NODE *finnode,int fincheck[]);
void readf(char *argv[9]);
void gate_level();

#endif
