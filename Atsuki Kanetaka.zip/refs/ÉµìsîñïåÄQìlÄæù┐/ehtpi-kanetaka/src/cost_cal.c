#include "metric_eval.h"

long long int cost_func_cal(){
	int in,ia,ib,flt_cnt=0;
	FLT_NODE *flt_node;
 double mul_flt_undet_p;//故障の他キャプチャで検出されていない確率の積
long long int cost_multi_p2=0;

 	double tmp=0.0;
 		 //printf("\n");
		 flt_node=fltlst.next;
		 for(; flt_node != NULL; flt_node = flt_node->next){
			 tmp=0.0;		mul_flt_undet_p=1.00000000000;
			 if(flt_node->saval==0){
		 			for(ib=0;ib<Cap;ib++){
		 				tmp=flt_node->back->C1[ib]*flt_node->back->O[ib+1];
		 				//tmp=fnode->fltdetp[ia][ib];
		 				if(tmp<ACAC) tmp=ACAC;
		 				mul_flt_undet_p*=(1-tmp);
		 			}
		 		}
		 		else{
		 				for(ib=0;ib<Cap;ib++){
		 				tmp=flt_node->back->C0[ib]*flt_node->back->O[ib+1];
		 				if(tmp<ACAC) tmp=ACAC;
		 				mul_flt_undet_p*=(1-tmp);
		 			}
		 		}

			/*	if((1-mul_flt_undet_p) < ACAC)  continue;
				flt_cnt++;
				cost_multi_p2+=(1/(1-mul_flt_undet_p));
*/
								flt_cnt++;
				if((1-mul_flt_undet_p) < ACAC) {
					cost_multi_p2+=(double)1/ACAC;

				}
				else {
					cost_multi_p2+=(double)(1/(1-mul_flt_undet_p));
				}

				//	if(1-mul_flt_undet_p ==0.0)
				//	printf("%f\n", 1-mul_flt_undet_p );

		 }
		 //exit(1);
return	cost_multi_p2/=(double)flt_cnt;
}
