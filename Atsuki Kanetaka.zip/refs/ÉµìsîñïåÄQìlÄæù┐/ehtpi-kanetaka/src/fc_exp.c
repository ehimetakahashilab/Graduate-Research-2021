#include "metric_eval.h"

double exp_fc_cal_per_pat(int patnum){
	int in,ia,ib,flt_cnt=0,node_cnt=0;
	FLT_NODE *flt_node;
	double exp_fc_comp=0.0;//sum(1-(1-pij)^PT)
 double mul_flt_undet_p;//故障の他キャプチャで検出されていない確率の積
 	double tmp=0.0;
 		// printf("\n");
		 int pocnt=0;
		 flt_node=fltlst.next;
		 for(; flt_node != NULL; flt_node = flt_node->next){
			 tmp=0.0;		mul_flt_undet_p=1.0;
			 if(flt_node->saval==0){
		 			for(ib=0;ib<Cap;ib++){
		 				tmp=flt_node->back->C1[ib]*flt_node->back->O[ib+1];
		 				//tmp=fnode->fltdetp[ia][ib];
		 				if(tmp<ACAC) tmp=ACAC;
		 				mul_flt_undet_p*=(1-tmp);
		 			}
		 		}
		 		else if(flt_node->saval==1){
		 				for(ib=0;ib<Cap;ib++){
		 				tmp=flt_node->back->C0[ib]*flt_node->back->O[ib+1];
		 				if(tmp<ACAC) tmp=ACAC;
		 				mul_flt_undet_p*=(1-tmp);
		 			}
		 		}
				if((1-mul_flt_undet_p) < ACAC) continue;
					flt_cnt++;
		 		exp_fc_comp+=(1-pow(mul_flt_undet_p,patnum));
		 }
		//printf("\n");
		exp_fc_comp/=(double)flt_cnt;// sum(1-(1-pij)^PT)/#F
////exit(1);
return (double)exp_fc_comp;
}

