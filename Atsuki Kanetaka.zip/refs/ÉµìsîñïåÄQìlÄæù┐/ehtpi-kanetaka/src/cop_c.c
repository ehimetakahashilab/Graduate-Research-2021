////////////////////////////////////////////////////////////////////////
//  INCLUDE & MACRO
////////////////////////////////////////////////////////////////////////

#include "cop.h"

void COP_C(int Cycle)	//compute the controllability value for COP method
{
	int ia;
  L_NODE *fnode;
  FIN_NODE *finnode;
  double Temple,Temple1;
ia=0;
while(ia<=MaxLevel){
 fnode=gnode.next;
  for( ;fnode!=NULL;fnode=fnode->next){//if(fnode->cp_flag&&Cycle==1)	printf("XXXXX slected CP: %d -%d-\n",fnode->line, fnode->cp_flag);
if(fnode->level!=ia) continue;
if(fnode->cp_flag||fnode->sel_flag){
	fnode->C1[Cycle] = 0.5;
	fnode->C0[Cycle] = 0.5;
//#if DEBUG_CP
//if(Cycle==1)	printf("XXXXX slected CP: %d -%d- -%d-\n",fnode->line, fnode->sel_flag,fnode->cp_flag);
//#endif
}
else{
    finnode=fnode->finlst;
		switch (fnode->type) {
			case AND:
			case NAND:
			case NOT:
				Temple = finnode->node->C1[Cycle];
				break;
			case OR:
			case NOR:
				Temple = finnode->node->C0[Cycle];
				break;
			case XOR:
			case XNOR:
				Temple = finnode->node->C0[Cycle];
				Temple1 = finnode->node->C0[Cycle];
				break;
				// XORゲートをサポートできるようにする20201019
			case FAN:
				Temple = finnode->node->C0[Cycle];
			break;
			default:
				printf("COP-C0 warring: node -%d-, type -%d- \n", fnode->line,fnode->type);
				//exit(1);
		}

		finnode = finnode->next;
		for (; finnode != NULL; finnode = finnode->next) {
			switch (fnode->type) {
				case AND:
				case NAND:
					Temple *= finnode->node->C1[Cycle];
					break;
				case OR:
				case NOR:
					Temple *= finnode->node->C0[Cycle];
					break;
				case NOT:
				case FAN:
					// case PO:
					// Temple=finnode->node->C1[Cycle];
					break;
				case XOR:
				case XNOR:
					Temple += finnode->node->C0[Cycle];
					Temple1 *= finnode->node->C0[Cycle];
					break;
					// XORゲートをサポートできるようにする20201019
	//			case FAN:
   	//			Temple = finnode->node->C0[Cycle];
	//			break;
				default:
				printf("COP-C0 warring: node -%d-, type -%d- \n", fnode->line,fnode->type);
					//exit(1);
			}
		}

		switch (fnode->type) {
			case AND:
				fnode->C1[Cycle] = Temple;
				fnode->C0[Cycle] = 1 - Temple;
				break;
			case NAND:
				fnode->C1[Cycle] = 1 - Temple;
				fnode->C0[Cycle] = Temple;
				break;
			case OR:
				fnode->C1[Cycle] = 1 - Temple;
				fnode->C0[Cycle] = Temple;
				break;
			case NOR:
				fnode->C1[Cycle] = Temple;
				fnode->C0[Cycle] = 1 - Temple;
				break;
			case NOT:
				fnode->C1[Cycle] = 1 - Temple;
				fnode->C0[Cycle] = Temple;
				break;
  		case FAN:
			fnode->C1[Cycle] = 1- Temple;
			fnode->C0[Cycle] = Temple;
			break;
			case XOR:
			case XNOR:
				fnode->C0[Cycle] = 1 - Temple + 2 * Temple1;
				fnode->C1[Cycle] = 1 - fnode->C0[Cycle];
				break;
			// case PO:
			//	fnode->C1[Cycle]=Temple;
			//	fnode->C0[Cycle]=1-Temple;
			//	break;
			default:
				printf("COP-C0 warring: node -%d-, type -%d- \n", fnode->line,fnode->type);
				//exit(1);
		}
	}
		if(!Cycle) 		fnode->C0[Cap+2]=0;//サイクルごとのCを記録し、後で平均をとる。
		fnode->C0[Cap+2]+=fnode->C0[Cycle];//サイクルごとのCを記録し、後で平均をとる。
	//	printf("%f, ",fnode->C0[Cap+2]);
	}
	ia++;
}
//printf("\n");
  finnode=ffnode.next;
  for(; finnode!=NULL; finnode=finnode->next){
    fnode=finnode->node;
	//	printf("FF Node: %d \n",fnode->line);
	if(fnode->cp_flag||fnode->sel_flag) {
		fnode->C1[Cycle+1]=0.5;
		fnode->C0[Cycle+1]=0.5;
	}
	else{
	fnode->C1[Cycle+1]=fnode->finlst->node->C1[Cycle];
	fnode->C0[Cycle+1]=fnode->finlst->node->C0[Cycle];
	}
	if(!Cycle) 		fnode->C0[Cap+2]=0;//サイクルごとのCを記録し、後で平均をとる。
	fnode->C0[Cap+2]+=fnode->C0[Cycle+1];//サイクルごとのCを記録し、後で平均をとる。
}

 /*fnode=gnode.next;
  for( ;fnode!=NULL;fnode=fnode->next){
if(fnode->type!=PO) continue;
if(fnode->finlst->node->type==FF){
	fnode->C1[Cycle]=fnode->finlst->node->C1[Cycle+1];
	fnode->C0[Cycle]=fnode->finlst->node->C0[Cycle+1];
	}
else{
	fnode->C1[Cycle]=fnode->finlst->node->C1[Cycle];
	fnode->C0[Cycle]=fnode->finlst->node->C0[Cycle];
	}

}*/
}
