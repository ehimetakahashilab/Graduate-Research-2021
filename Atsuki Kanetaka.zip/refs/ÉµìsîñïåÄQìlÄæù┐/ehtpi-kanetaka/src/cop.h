//functions for controllability or observability computing
#ifndef __COP_H__
#define __COP_H__

#include "tpi_def.h"
void COP_C(int Cycle);
void COP_O(int Cycle);

void SCOAP_O(int Cycle);		//compute the observability value for SCOAP method
void SCOAP_C(int Cycle);		//compute the observability value for SCOAP method

#endif
