#include"struct_eval.h"


void type1_3(L_NODE *gt_head,FIN_NODE *ff_head)	//forward trace from gate

{
	int in,ia,ib,constraint1,constraint2,constraint3;
 	L_NODE *fnode,*ff_node;
	FIN_NODE *finnode;
 	FILE *fout,*fout1;

//printf("here?\n");
finnode=ff_head;
for(in=1; finnode!=NULL; finnode=finnode->next,in++){
    	ff_node=finnode->node;
//printf("FF:%d %d ",ff_node->line,ff_node->type);
	constraint1=0;
	for(ia=0;ia<ff_node->eval_C[4];ia++){
	  if(ff_node->line==ff_node->ff_out_path[ia]){
		  constraint1=1; break;
			}
		}
//printf("%d \n",constraint1);
	fnode=gt_head;
	for( ;fnode!=NULL;fnode=fnode->next){
		//if(fnode->eval_C[4]!=1) continue;

		constraint2=0;
		for(ib=0;ib<fnode->eval_C[4];ib++){
		if(fnode->ff_out_path[ib]==ff_node->line){
				constraint2=1;break;
				}
			}
		constraint3=0;
			for(ia=0;ia<fnode->eval_C[1];ia++){
				if(ff_node->line==fnode->ff_in_path[ia]){
					constraint3=1;	break;
						}
					}
			if(constraint2==1){
				if(constraint3==1) ff_node->TYPE[0]++;
				else {
					if(constraint1==1) ff_node->TYPE[1]++;
					else ff_node->TYPE[2]++;
					}
				}

			}
		}

}
