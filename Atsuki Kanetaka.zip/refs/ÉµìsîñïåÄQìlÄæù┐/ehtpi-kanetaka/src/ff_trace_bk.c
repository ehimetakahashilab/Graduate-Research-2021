
#include"struct_eval.h"

void ff_back_trace(FIN_NODE *ff_head)
{
	int in,ia,ib,Node1Num,Node2Num;
 	FIN_NODE *finnode,*faninlst;
 	L_NODE *fnode,*fnode1,*fnode2,**node1,**temnode;
	int width[MaxLevel+1],tmp_width;
node1 = (L_NODE **)calloc(numgate+2, sizeof(L_NODE *));
temnode=(L_NODE **)calloc(numgate+2, sizeof(L_NODE *));

if(node1 == NULL)     printf("memory error @node1\n"),exit(1);
if(temnode == NULL)    printf("memory error @temnode\n"),exit(1);

printf("ffnum=%d gate_num=%d\n",ffnum,numgate);

  	finnode=ff_head;

  for(in=0;finnode!=NULL;finnode=finnode->next,ia++){
	Node1Num=0;
	for(ia=0;ia<numgate;ia++)
		node1[ia]=NULL;
	for(ia=0;ia<=MaxLevel;ia++)
		width[ia]=0;
	fnode=finnode->node;
	node1[0]=fnode;
	Node1Num=1;
	fnode->bk_depth=0;
	fnode->bk_width=0;
 	fnode->bk_pi_dis=0;
	int stop_flag=0;

	for(ia=0;ia<ffnum;ia++)
		fnode->ff_in_path[ia]=0;

	for(ia=0;ia<6;ia++)
		for(ib=0;ib<3;ib++)
		 fnode->gt_cnt[ia][ib]=0;

	fnode->arrive_branch=0;
	fnode->total_branch=0;

	while(Node1Num>0){

		Node2Num=0;

if(fnode==node1[0]){
		fnode->eval_C[2]=0;
		fnode->eval_C[3]=0;
	}
else {
		fnode->eval_C[3]++;
		fnode->eval_C[2]+=Node1Num;
}
		for(ia=0;ia<numgate;ia++)temnode[ia]=NULL;
///////////////////////////////////////////////////////////////////////////////
		for(ia=0;ia<Node1Num;ia++){
			fnode1=node1[ia];
			//printf("%d %d %d ",fnode1->line,fnode1->type,fnode1->fltList[0]);
			width[fnode1->level]++;
			switch(fnode1->type){
				case OR:
					fnode->gt_cnt[0][fnode1->nfin-1]++;
					break;
				case NOR:
					fnode->gt_cnt[1][fnode1->nfin-1]++;
					break;
				case AND:
					fnode->gt_cnt[2][fnode1->nfin-1]++;
					break;
				case NAND:
					fnode->gt_cnt[3][fnode1->nfin-1]++;
					break;
				case NOT:
					fnode->gt_cnt[4][fnode1->nfin-1]++;
					break;
				case XOR:
					fnode->gt_cnt[5][fnode1->nfin-1]++;
					break;
				case FF: break;
				default:
					printf("error: unsupported gate\n"),exit(1);
				}

		fnode->arrive_branch++;
		fnode->total_branch+=fnode1->nfout;

			faninlst=fnode1->finlst;
			for(;faninlst!=NULL;faninlst=faninlst->next){
				fnode2=faninlst->node;
				int flag=0;
				for(ib=0;ib<Node2Num;ib++){
					if(temnode[ib]==fnode2){
						flag=1;break;
							}
						}
				if(flag==0){
					temnode[Node2Num]=fnode2;
					Node2Num++;
					}
				}
			}
////////////////////////////////////////////////////////////////////////////
	for(ia=0;ia<numgate;ia++) node1[ia]=NULL;
	Node1Num=0;

	//if(Node2Num>=fnode->bk_width) fnode->bk_width=Node2Num;

	for(ia=0;ia<Node2Num;ia++){
			if(temnode[ia]->type==PI)
					stop_flag=1;

			if(temnode[ia]->type==FF){

				fnode->ff_in_path[fnode->eval_C[1]]=temnode[ia]->line;
				fnode->eval_C[1]++;
#if Debug
printf("A FF: %d %d %d\n",temnode[ia]->type, temnode[ia]->line,fnode->eval_C[1]);//exit(1);
#endif
				}
			if(temnode[ia]->type!=FF&&temnode[ia]->type!=PI){
#if NODE_REC
				int flag=0;
				for(ib=0;ib<fnode->bk_traced_node_num;ib++){
					if(temnode[ia]==fnode->bk_traced_node[ib]){
							flag=1; break;
							}
						}
				if(flag==1) continue;
				if(temnode[ia]->level>=fnode->bk_depth) fnode->bk_depth=temnode[ia]->level;
				fnode->bk_traced_node[fnode->bk_traced_node_num] = temnode[ia];
				fnode->bk_traced_node_num++;
#endif

				node1[Node1Num]=temnode[ia];
				fnode->eval_C[7]+=node1[Node1Num]->eval_C[7];
				Node1Num++;
				//printf("%d %d %d hehre?\n",Node2Num,fnode->bk_traced_node_num,temnode[ia]->level);
				//fnode->bk_gt_list[0]++;
				//fnode->bk_gt_list[fnode->bk_gt_list[0]]=temnode[ia]->line;
				}
			}
 		if(stop_flag==0) fnode->bk_pi_dis++;
////////////////////////////////////////////////////////////////////////////
	}
	for(ia=0;ia<=MaxLevel;ia++)
		if(width[ia]>=fnode->bk_width) fnode->bk_width=width[ia];

}//printf("end\n");
free(node1);
free(temnode);
}

//後方追跡：単一ノードから、追跡のみ、記録なし、必要に応じてノードを記録してください。
void ff_back_trace_single(FIN_NODE *origin_node)
{
	int in,ia,ib,Node1Num,Node2Num;
 	FIN_NODE *finnode,*faninlst;
 	L_NODE *fnode,*fnode1,*fnode2,**node1,**temnode;
	int width[MaxLevel+1],tmp_width;
node1 = (L_NODE **)calloc(numgate+2, sizeof(L_NODE *));
temnode=(L_NODE **)calloc(numgate+2, sizeof(L_NODE *));

if(node1 == NULL)     printf("memory error @node1\n"),exit(1);
if(temnode == NULL)    printf("memory error @temnode\n"),exit(1);

printf("ffnum=%d gate_num=%d\n",ffnum,numgate);

	Node1Num=0;
	for(ia=0;ia<numgate;ia++)
		node1[ia]=NULL;
	for(ia=0;ia<=MaxLevel;ia++)
		width[ia]=0;
	fnode=origin_node->node;
	node1[0]=fnode;
	Node1Num=1;

	while(Node1Num>0){

		Node2Num=0;

		for(ia=0;ia<numgate;ia++)temnode[ia]=NULL;
///////////////////////////////////////////////////////////////////////////////
		for(ia=0;ia<Node1Num;ia++){
			fnode1=node1[ia];
			faninlst=fnode1->finlst;
			for(;faninlst!=NULL;faninlst=faninlst->next){
				fnode2=faninlst->node;
				int flag=0;
				for(ib=0;ib<Node2Num;ib++){
					if(temnode[ib]==fnode2){
						flag=1;break;
							}
						}
				if(flag==0){
					temnode[Node2Num]=fnode2;
					Node2Num++;
					}
				}
			}
////////////////////////////////////////////////////////////////////////////
	for(ia=0;ia<numgate;ia++) node1[ia]=NULL;
	Node1Num=0;

	for(ia=0;ia<Node2Num;ia++){

			if(temnode[ia]->type!=FF&&temnode[ia]->type!=PI){
				node1[Node1Num]=temnode[ia];
				Node1Num++;
				//printf("%d %d %d hehre?\n",Node2Num,fnode->bk_traced_node_num,temnode[ia]->level);
				//fnode->bk_gt_list[0]++;
				//fnode->bk_gt_list[fnode->bk_gt_list[0]]=temnode[ia]->line;
				}
			}
	}
free(node1);
free(temnode);
}
