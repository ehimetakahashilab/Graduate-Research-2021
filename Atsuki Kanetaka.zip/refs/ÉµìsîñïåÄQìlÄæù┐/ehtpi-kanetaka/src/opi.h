//functions for controllability or observability computing
#ifndef __OPI_H__
#define __OPI_H__

#include"tpi_def.h"
#include"struct_eval.h"
#include"metric_eval.h"
#include"cop.h"
#include"initial.h"

#define FCOV_DECREMENT_BOUND 0.1
#define FF_CP_SEL 0
#define OP_CANDI_NUM 5
#define STRUCT_TERMS 5
#define TREND 1



#define OP_SEL_MODE 1 //=1:remove unnecessary OP =2: searching necessary OPs
#define STRUCTURE_OP 1 //=1: structure analizing, TOPSIS ranking


void cp_setting(char *cp_path, int cp_num);
void topsis_cal(double **eval_val,int TermNum);
int topsis_cal_gener(double **eval_val,int TermNum, int member);
void topsis_rank_prn(int direct,FILE *fout);
void copy_back(double *eval);
void refresh_all_opnode();
void op_prn();
int rm_one_op_by_expfc(L_NODE **candi_list,int aviable_op_num);

void create_stuct_val_table(double **val_table);
void opi_main(float op_rate,char *op_path);
int ff_routing_check();
int pull_one_op_by_cost(L_NODE **candi_list,int aviable_op_num);
int explor_candi_op_by_topsis(L_NODE *candi_list[]);

#endif
