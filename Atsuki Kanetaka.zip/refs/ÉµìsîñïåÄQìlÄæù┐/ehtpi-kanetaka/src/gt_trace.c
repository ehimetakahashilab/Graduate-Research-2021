
#include"struct_eval.h"

void trace_initial(L_NODE *gt_head,FIN_NODE *ff_head)
{
int ia,ib,ic;
FIN_NODE *finnode;
L_NODE *fnode;

finnode=ff_head;

 for(; finnode!=NULL; finnode=finnode->next){
    fnode=finnode->node;
	fnode->total_branch=0;
	fnode->arrive_branch=0;
	for(ia=0;ia<=ffnum;ia++){
		fnode->ff_in_path[ia]=0;
		fnode->ff_out_path[ia]=0;
		if(ia<=7)
		fnode->eval_C[ia]=0;
		if(ia<=3) fnode->TYPE[ia]=0;
		for(ib=0;ia<=6&&ib<=3;ib++)
			fnode->gt_cnt[ia][ib]=0;
		}
	}

fnode=gt_head;
 for(; fnode!=NULL; fnode=fnode->next){
if(fnode->type==PO) continue;
	fnode->total_branch=0;
	fnode->arrive_branch=0;

	for(ia=0;ia<=ffnum;ia++){
		fnode->ff_in_path[ia]=0;
		fnode->ff_out_path[ia]=0;
		if(ia<=7)
		fnode->eval_C[ia]=0;
		if(ia<=3) fnode->TYPE[ia]=0;
		for(ib=0;ia<=6&&ib<=3;ib++)
			fnode->gt_cnt[ia][ib]=0;
		}
//printf("%d\n",fnode->line);
	}

}

void gt_forw_trace(L_NODE *gt_head)
{
  int ia,ib,Node1Num,Node2Num,flag;
  FIN_NODE *fanoutlst;
  L_NODE *fnode,*fnode1,*fnode2,**node1,**temnode;

node1 = (L_NODE **)calloc(numgate+1, sizeof(L_NODE *));
temnode=(L_NODE **)calloc(numgate+1, sizeof(L_NODE *));

if(node1 == NULL)     printf("memory error @node1\n"),exit(1);
if(temnode == NULL)    printf("memory error @temnode\n"), exit(1);

printf("ffnum=%d gate_num=%d\n",ffnum,numgate);

 fnode=gt_head;
  for( ;fnode!=NULL;fnode=fnode->next){

	for(ia=0;ia<numgate;ia++)
		node1[ia]=NULL;
	node1[0]=fnode;
	Node1Num=1;

	for(ia=0;ia<ffnum;ia++)
		fnode->ff_out_path[ia]=0;
#if Debug
printf("Node %d Value %d %d %d %d %d %d %d \n",fnode->line,fnode->eval_C[1],fnode->eval_C[2],fnode->eval_C[3],fnode->eval_C[4],fnode->eval_C[5],fnode->eval_C[6],fnode->eval_C[7]);
#endif

	while(Node1Num>0){

		Node2Num=0;
if(fnode==node1[0]){
		fnode->eval_C[5]=0;
		fnode->eval_C[6]=0;
	}
else {
		fnode->eval_C[6]++;
		fnode->eval_C[5]+=Node1Num;
}
		for(ia=0;ia<numgate;ia++)temnode[ia]=NULL;
///////////////////////////////////////////////////////////////////////////////
		for(ia=0;ia<Node1Num;ia++){
			fnode1=node1[ia];
			//printf("%d %d %d ",fnode1->line,fnode1->type,fnode1->fltList[0]);
			fanoutlst=fnode1->foutlst;
			for(;fanoutlst!=NULL;fanoutlst=fanoutlst->next){
				fnode2=fanoutlst->node;
				flag=0;
				for(ib=0;ib<Node2Num;ib++){
					if(temnode[ib]==fnode2){
						flag=1;break;
							}
						}
				if(flag==0){
					temnode[Node2Num]=fnode2;
					Node2Num++;
					}
				}
			}
////////////////////////////////////////////////////////////////////////////
	for(ia=0;ia<numgate;ia++) node1[ia]=NULL;
	Node1Num=0;
	for(ia=0;ia<Node2Num;ia++){
			if(temnode[ia]->type==FF){
				fnode->ff_out_path[fnode->eval_C[4]]=temnode[ia]->line;
				fnode->eval_C[4]++;
//printf("A FF: %d %d %d\n",temnode[ia]->type, temnode[ia]->line,fnode->eval_C[4]),exit(1);
				}
			if(temnode[ia]->type!=FF&&temnode[ia]->type!=PO){
  #if NODE_REC
                		flag=0;
              for(ib=0;ib<fnode->fw_traced_node_num;ib++){
                	if(temnode[ia]==fnode->fw_traced_node[ib]){
                				flag=1; break;
                				}
                		}
                	if(flag==1) continue;
              		if(temnode[ia]->level>=fnode->fw_depth) fnode->fw_depth=temnode[ia]->level;
                	fnode->fw_traced_node[fnode->fw_traced_node_num] = temnode[ia];
                	fnode->fw_traced_node_num++;
                				//printf("%d %d %d hehre?\n",Node2Num,fnode->fw_traced_node_num,temnode[ia]->level);
                				//fnode->fw_gt_list[0]++;
                				//fnode->fw_gt_list[fnode->fw_gt_list[0]]=temnode[ia]->line;
  #endif
				node1[Node1Num]=temnode[ia];
				Node1Num++;
				}
			}
////////////////////////////////////////////////////////////////////////////
	}
for(ia=4;ia<=6;ia++)
	fnode->eval_C[7]+=fnode->eval_C[ia];
#if Debug
printf("After Node %d Value %d %d %d %d %d %d %d \n",fnode->line,fnode->eval_C[1],fnode->eval_C[2],fnode->eval_C[3],fnode->eval_C[4],fnode->eval_C[5],fnode->eval_C[6],fnode->eval_C[7]);
#endif
}
free(node1);
free(temnode);
}

void boundary_node_search(L_NODE *origin_node)
{
  int ia, ib,ic;
  FIN_NODE *faninlst;
  L_NODE *fnode,*fnode1;
  fnode=gnode.next;
  for(; fnode!=NULL; fnode=fnode->next) fnode->traced_flag=0;
  fnode=origin_node;
  fnode->boundary_node_num=0;
  for(ia=0;ia<fnode->fw_traced_node_num;ia++){
    faninlst=fnode->fw_traced_node[ia]->finlst;
        for(ib=0;faninlst!=NULL;faninlst=faninlst->next,ib++){
           fnode1=faninlst->node;
          if (fnode1->traced_flag==1) continue;
          for(ic=0;ic<fnode->fw_traced_node_num;ic++){
            if(fnode1==fnode->fw_traced_node[ic]){
              fnode1->traced_flag=1; break;
            }
          }
          if(!fnode1->traced_flag){
            fnode->boundary_node[fnode->boundary_node_num]=fnode1;
            fnode->boundary_node_num++;
          }
        }
  }
}

void gt_forw_trace_for_cpi(L_NODE *gt_head)
{
  int ia,ib,Node1Num,Node2Num,flag;
  FIN_NODE *fanoutlst;
  L_NODE *fnode,*fnode1,*fnode2,**node1,**temnode;

node1 = (L_NODE **)calloc(numgate+1, sizeof(L_NODE *));
temnode=(L_NODE **)calloc(numgate+1, sizeof(L_NODE *));

if(node1 == NULL)     printf("memory error @node1\n"),exit(1);
if(temnode == NULL)    printf("memory error @temnode\n"), exit(1);

printf("ffnum=%d gate_num=%d\n",ffnum,numgate);

/*for(ia=0;ia<numgate;ia++){
  node1[ia]=NULL;
  temnode[ia]=NULL;
}*/

 fnode=gt_head;
  for( ;fnode!=NULL;fnode=fnode->next){

	for(ia=0;ia<numgate;ia++)
		node1[ia]=NULL;
	node1[0]=fnode;
	Node1Num=1;
  fnode->fix_gt_0=0;
  fnode->fix_gt_1=0;

#if Debug
//printf(" Start CPI candinate #%d, fix0=%d fix1=%d\n",fnode->line,fnode->fix_gt_0,fnode->fix_gt_1);
//printf("After Node %d Value %d %d %d %d %d %d %d \n",fnode->line,fnode->eval_C[1],fnode->eval_C[2],fnode->eval_C[3],fnode->eval_C[4],fnode->eval_C[5],fnode->eval_C[6],fnode->eval_C[7]);
#endif
	while(Node1Num>0){

		Node2Num=0;
		for(ia=0;ia<numgate;ia++)temnode[ia]=NULL;
///////////////////////////////////////////////////////////////////////////////
		for(ia=0;ia<Node1Num;ia++){
			fnode1=node1[ia];
  /*         if(fnode1==fnode) {
             //fnode1->fix0=1;
            // fnode1->fix1=1;
              fnode->fix_gt_0=0;
              fnode->fix_gt_1=0;
            }*/
			//printf("%d %d %d ",fnode1->line,fnode1->type,fnode1->fltList[0]);


			fanoutlst=fnode1->foutlst;
			for(;fanoutlst!=NULL;fanoutlst=fanoutlst->next){
				fnode2=fanoutlst->node;
        fix_gt_check(fnode,fnode1,fnode2);

      if(fnode2->fix0)   fnode->fix_gt_0++;
      if(fnode2->fix1)   fnode->fix_gt_1++;
      // fnode2->fix0=0;fnode2->fix1=0;
				flag=0;
				for(ib=0;ib<Node2Num;ib++){
					if(temnode[ib]==fnode2){
						flag=1;break;
							}
						}
				if(flag==0){
					temnode[Node2Num]=fnode2;
					Node2Num++;
					}
				}
			}
////////////////////////////////////////////////////////////////////////////
	for(ia=0;ia<numgate;ia++) node1[ia]=NULL;
	Node1Num=0;
	for(ia=0;ia<Node2Num;ia++){
	 if(temnode[ia]->type!=FF&&temnode[ia]->type!=PO){
				node1[Node1Num]=temnode[ia];
				Node1Num++;
				}
			}
////////////////////////////////////////////////////////////////////////////
	}

#if Debug
//if(fnode->line==4951)
printf("CPI candinate #%d, fix0=%d fix1=%d\n",fnode->line,fnode->fix_gt_0,fnode->fix_gt_1);
#endif
}
free(node1);
free(temnode);
}


void gt_forw_trace_for_cpi_single(L_NODE *origin_node)
{
  int ia,ib,Node1Num,Node2Num,flag;
  FIN_NODE *fanoutlst;
  L_NODE *fnode,*fnode1,*fnode2,**node1,**temnode;
  node1 = (L_NODE **)calloc(numgate+1, sizeof(L_NODE *));
  temnode=(L_NODE **)calloc(numgate+1, sizeof(L_NODE *));
  fnode=origin_node;

   //for(ia=0;ia<numgate;ia++)
  //   node1[ia]=NULL;
   node1[0]=fnode;
   Node1Num=1;
   fnode->fix_gt_0=0;
   fnode->fix_gt_1=0;
   while(Node1Num>0){
     Node2Num=0;
  //   for(ia=0;ia<numgate;ia++)temnode[ia]=NULL;
 ///////////////////////////////////////////////////////////////////////////////
     for(ia=0;ia<Node1Num;ia++){
       fnode1=node1[ia];
       //printf("%d %d %d ",fnode1->line,fnode1->type,fnode1->fltList[0]);
       fanoutlst=fnode1->foutlst;
       for(;fanoutlst!=NULL;fanoutlst=fanoutlst->next){
         fnode2=fanoutlst->node;
         fix_gt_check(fnode,fnode1,fnode2);

       if(fnode2->fix0)   fnode->fix_gt_0++;
       if(fnode2->fix1)   fnode->fix_gt_1++;
  //     fnode2->fix0=0;fnode2->fix1=0;
         flag=0;
         for(ib=0;ib<Node2Num;ib++){
           if(temnode[ib]==fnode2){
             flag=1;break;
               }
             }
         if(flag==0){
           temnode[Node2Num]=fnode2;
           Node2Num++;
           }
         }
       }
 ////////////////////////////////////////////////////////////////////////////
   //for(ia=0;ia<Node1Num+1;ia++) node1[ia]=NULL;
   Node1Num=0;
   for(ia=0;ia<Node2Num;ia++){
       if(temnode[ia]->type!=FF&&temnode[ia]->type!=PO){
         node1[Node1Num]=temnode[ia];
         Node1Num++;
         }
       }
 ////////////////////////////////////////////////////////////////////////////

   }

 free(node1);
  free(temnode);
}

void fix_gt_check(L_NODE *origin_node,L_NODE *main_node,L_NODE *slave_node)
{
	slave_node->fix0=0;
	slave_node->fix1=0;
	if(main_node==origin_node) {
		if(slave_node->type==OR||slave_node->type==NOR){
			//    origin_node->fix_gt_1++; //start point of cp candinate
				//  fix1_flag++;
					slave_node->fix1=1;
				}
	if(slave_node->type==NAND||slave_node->type==AND){
			//    origin_node->fix_gt_0++; //start point of cp candinate
			//    fix0_flag++;
					slave_node->fix0=1;
				}
	if(slave_node->type==NOT) {
			slave_node->fix0=1;
			slave_node->fix1=1;
		}
			}
	else{

	switch(main_node->type){ //origin gate
		case NAND:
		if(main_node->fix0){
			switch(slave_node->type){
				case OR: slave_node->fix0=1;break;
				case NOR: slave_node->fix0=1;break;
				case NOT: slave_node->fix0=1;break;
//			  default: printf("Warning: main node type: %d, slave type %d is not supported \n",main_node->type,slave_node->type);
			}
		}
		if(main_node->fix1){
			switch(slave_node->type){
				case OR: slave_node->fix1=1;break;
				case NOR: slave_node->fix1=1;break;
				case NOT: slave_node->fix1=1;break;
//			  default: printf("Warning: main node type: %d, slave type %d is not supported \n",main_node->type,slave_node->type);
			}
		}
					break;
		case AND:
		if(main_node->fix0){
				switch(slave_node->type){
					case AND: slave_node->fix0=1;break;
					case NAND: slave_node->fix0=1;break;
					case NOT: slave_node->fix0=1;break;
	//		  default: printf("Warning: main node type: %d, slave type %d is not supported \n",main_node->type,slave_node->type);
				}
			}
			if(main_node->fix1){
					switch(slave_node->type){
						case AND: slave_node->fix1=1;break;
						case NAND: slave_node->fix1=1;break;
						case NOT: slave_node->fix1=1;break;
//			  default: printf("Warning: main node type: %d, slave type %d is not supported \n",main_node->type,slave_node->type);
					}
				}
						break;

		case NOR:
		if(main_node->fix0){
			switch(slave_node->type){
				case AND: slave_node->fix0=1;break;
				case NAND: slave_node->fix0=1;break;
				case NOT: slave_node->fix0=1;break;
//			  default: printf("Warning: main node type: %d, slave type %d is not supported \n",main_node->type,slave_node->type);
			}
		}
		if(main_node->fix1){
			switch(slave_node->type){
				case AND: slave_node->fix1=1;break;
				case NAND: slave_node->fix1=1;break;
				case NOT: slave_node->fix1=1;break;
	//		  default: printf("Warning: main node type: %d, slave type %d is not supported \n",main_node->type,slave_node->type);
			}
		}
					break;

		case OR:
		if(main_node->fix1){
			switch(slave_node->type){
				case OR: slave_node->fix1=1;break;
				case NOR: slave_node->fix1=1;break;
				case NOT: slave_node->fix1=1;break;
		//	  default: printf("Warning: main node type: %d, slave type %d is not supported \n",main_node->type,slave_node->type);
			}
		}
		if(main_node->fix0){
			switch(slave_node->type){
				case OR: slave_node->fix0=1;break;
				case NOR: slave_node->fix0=1;break;
				case NOT: slave_node->fix0=1;break;
			//  default: printf("Warning: main node type: %d, slave type %d is not supported \n",main_node->type,slave_node->type);
			}
		}
					break;

		case NOT:
		case XOR:
		case XNOR:
		if(main_node->fix0){
			switch(slave_node->type){
				case AND: slave_node->fix0=1;break;
				case NAND: slave_node->fix0=1;break;
				case NOT: slave_node->fix0=1;break;
	//		  default: printf("Warning: main node type: %d, slave type %d is not supported \n",main_node->type,slave_node->type);
		}
	}
		if(main_node->fix1){
			switch(slave_node->type){
				case OR: slave_node->fix1=1;break;
				case NOR: slave_node->fix1=1;break;
				case NOT: slave_node->fix1=1;break;
		//	  default: printf("Warning: main node type: %d, slave type %d is not supported \n",main_node->type,slave_node->type);
		}
	}
			break;
	 default: printf("error in 'gt_trace.c', %d gate is not supported \n", main_node->type ),exit(1);
	}
}
}
/*

int gt_forw_trace_for_overlap(L_NODE *origin_node,int *nodes,int ovnode_num)
{
  int ia,ib,Node1Num,Node2Num,flag, flag1;
  FIN_NODE *fanoutlst;
  L_NODE *fnode,*fnode1,*fnode2,**node1,**temnode;
  node1 = (L_NODE **)calloc(numgate+1, sizeof(L_NODE *));
  temnode=(L_NODE **)calloc(numgate+1, sizeof(L_NODE *));
  int unoverlap_gt=0,ic;
printf("\nin->Overlap gates = %d %d \n",unoverlap_gt, ovnode_num);
  fnode=origin_node;
   //for(ia=0;ia<numgate;ia++)
  //   node1[ia]=NULL;
   node1[0]=fnode;
   Node1Num=1;
   while(Node1Num>0){
     Node2Num=0;
     for(ia=0;ia<numgate;ia++)temnode[ia]=NULL;
 ///////////////////////////////////////////////////////////////////////////////
     for(ia=0;ia<Node1Num;ia++){
       fnode1=node1[ia];
       //printf("%d %d %d ",fnode1->line,fnode1->type,fnode1->fltList[0]);
       fanoutlst=fnode1->foutlst;
       for(;fanoutlst!=NULL;fanoutlst=fanoutlst->next){
         fnode2=fanoutlst->node;

  //     fnode2->fix0=0;fnode2->fix1=0;
         flag=0;
         for(ib=0;ib<Node2Num;ib++){
           if(temnode[ib]==fnode2){
             flag=1;break;
               }
             }
         if(flag==0){
           temnode[Node2Num]=fnode2;
           Node2Num++;
           }
         }
       }
 ////////////////////////////////////////////////////////////////////////////
   for(ia=0;ia<Node1Num+1;ia++) node1[ia]=NULL;
   Node1Num=0;
   for(ia=0;ia<Node2Num;ia++){
       if(temnode[ia]->type!=FF&&temnode[ia]->type!=PO){
             flag=0;
              for(ib=0;ib<ovnode_num;ib++){
               if(temnode[ia]->line==nodes[ib]) {flag=1;break;}
              }
              if(!flag) {
                unoverlap_gt++;
                nodes[ovnode_num]=temnode[ia]->line; ovnode_num++;
              }

         node1[Node1Num]=temnode[ia];
         Node1Num++;
         }
       }
 ////////////////////////////////////////////////////////////////////////////
   }
printf("\nOverlap gates = %d %d \n",unoverlap_gt, ovnode_num);
 free(node1);
  free(temnode);
  return unoverlap_gt;
}
*/


void gt_back_trace(L_NODE *gt_head)
{
  int ia,ib,Node1Num,Node2Num,flag;
  FIN_NODE *faninlst;
  L_NODE *fnode,*fnode1,*fnode2,**node1,**temnode;


node1 = (L_NODE **)calloc(numgate+1, sizeof(L_NODE *));
temnode=(L_NODE **)calloc(numgate+1, sizeof(L_NODE *));
if(node1 == NULL)     printf("memory error @node1\n"),exit(1);
if(temnode == NULL)    printf("memory error @temnode\n"),exit(1);
printf("ffnum=%d gate_num=%d\n",ffnum,numgate);

 fnode=gt_head;
  for( ;fnode!=NULL;fnode=fnode->next){

	for(ia=0;ia<numgate;ia++)
		node1[ia]=NULL;
	node1[0]=fnode;
	Node1Num=1;
	for(ia=0;ia<ffnum;ia++)
		fnode->ff_in_path[ia]=0;
#if Debug
printf("Node %d Value %d %d %d %d %d %d %d \n",fnode->line,fnode->eval_C[1],fnode->eval_C[2],fnode->eval_C[3],fnode->eval_C[4],fnode->eval_C[5],fnode->eval_C[6],fnode->eval_C[7]);
#endif
	while(Node1Num>0){

		Node2Num=0;
if(fnode==node1[0]){
		fnode->eval_C[2]=0;
		fnode->eval_C[3]=0;
	}
else {
		fnode->eval_C[3]++;
		fnode->eval_C[2]+=Node1Num;
}
		for(ia=0;ia<numgate;ia++)temnode[ia]=NULL;
///////////////////////////////////////////////////////////////////////////////
		for(ia=0;ia<Node1Num;ia++){
			fnode1=node1[ia];
			//printf("%d %d %d ",fnode1->line,fnode1->type,fnode1->fltList[0]);
			faninlst=fnode1->finlst;
			for(;faninlst!=NULL;faninlst=faninlst->next){
				fnode2=faninlst->node;
				flag=0;
				for(ib=0;ib<Node2Num;ib++){
					if(temnode[ib]==fnode2){
						flag=1;break;
							}
						}
				if(flag==0){
					temnode[Node2Num]=fnode2;
					Node2Num++;
					}
				}
			}
////////////////////////////////////////////////////////////////////////////
	for(ia=0;ia<numgate;ia++) node1[ia]=NULL;
	Node1Num=0;
	for(ia=0;ia<Node2Num;ia++){
			if(temnode[ia]->type==FF){
				fnode->ff_in_path[fnode->eval_C[1]]=temnode[ia]->line;
				fnode->eval_C[1]++;
				}
			if(temnode[ia]->type!=FF&&temnode[ia]->type!=PI){
#if NODE_REC
        		 flag=0;
        	for(ib=0;ib<fnode->bk_traced_node_num;ib++){
        		if(temnode[ia]==fnode->bk_traced_node[ib]){
        					flag=1; break;
        					}
        			}
      	if(flag==1) continue;
        if(temnode[ia]->level>=fnode->bk_depth) fnode->bk_depth=temnode[ia]->level;
        	fnode->bk_traced_node[fnode->bk_traced_node_num] = temnode[ia];
        	fnode->bk_traced_node_num++;
#endif
				node1[Node1Num]=temnode[ia];
				Node1Num++;
				}
			}
////////////////////////////////////////////////////////////////////////////
	}

for(ia=1;ia<=3;ia++)
	fnode->eval_C[7]+=fnode->eval_C[ia];
#if Debug
printf("After Node %d Value %d %d %d %d %d %d %d \n",fnode->line,fnode->eval_C[1],fnode->eval_C[2],fnode->eval_C[3],fnode->eval_C[4],fnode->eval_C[5],fnode->eval_C[6],fnode->eval_C[7]);
#endif

}
free(node1);
free(temnode);
}

void gt_back_trace_single(L_NODE *origin_node)
{
  int ia,ib,Node1Num,Node2Num,flag;
  FIN_NODE *faninlst;
  L_NODE *fnode,*fnode1,*fnode2,**node1,**temnode;

node1 = (L_NODE **)calloc(numgate+1, sizeof(L_NODE *));
temnode=(L_NODE **)calloc(numgate+1, sizeof(L_NODE *));
if(node1 == NULL)     printf("memory error @node1\n"),exit(1);
if(temnode == NULL)    printf("memory error @temnode\n"),exit(1);
printf("ffnum=%d gate_num=%d\n",ffnum,numgate);

 fnode=origin_node;

	for(ia=0;ia<numgate;ia++)
		node1[ia]=NULL;
	node1[0]=fnode;
	Node1Num=1;

#if Debug
printf("Node %d Value %d %d %d %d %d %d %d \n",fnode->line,fnode->eval_C[1],fnode->eval_C[2],fnode->eval_C[3],fnode->eval_C[4],fnode->eval_C[5],fnode->eval_C[6],fnode->eval_C[7]);
#endif
	while(Node1Num>0){

		Node2Num=0;
		for(ia=0;ia<numgate;ia++)temnode[ia]=NULL;
///////////////////////////////////////////////////////////////////////////////
		for(ia=0;ia<Node1Num;ia++){
			fnode1=node1[ia];
			faninlst=fnode1->finlst;
			for(;faninlst!=NULL;faninlst=faninlst->next){
				fnode2=faninlst->node;
				flag=0;
				for(ib=0;ib<Node2Num;ib++){
					if(temnode[ib]==fnode2){
						flag=1;break;
							}
						}
				if(flag==0){
					temnode[Node2Num]=fnode2;
					Node2Num++;
					}
				}
			}
////////////////////////////////////////////////////////////////////////////
	for(ia=0;ia<numgate;ia++) node1[ia]=NULL;
	Node1Num=0;
	for(ia=0;ia<Node2Num;ia++){
			if(temnode[ia]->type!=FF&&temnode[ia]->type!=PI){
				node1[Node1Num]=temnode[ia];
				Node1Num++;
				}
			}
////////////////////////////////////////////////////////////////////////////
	}

#if Debug
printf("After Node %d Value %d %d %d %d %d %d %d \n",fnode->line,fnode->eval_C[1],fnode->eval_C[2],fnode->eval_C[3],fnode->eval_C[4],fnode->eval_C[5],fnode->eval_C[6],fnode->eval_C[7]);
#endif

free(node1);
free(temnode);
}
