#ifndef __INITIAL_H__
#define __INITIAL_H__

#include"tpi_def.h"

void OPI_ff_initiallization();
void rm_ff_initiallization();
void CPI_initiallization();
void ini_for_trace();
void ini_for_testability();
void initiallization();
void initiallization_2();

#endif
