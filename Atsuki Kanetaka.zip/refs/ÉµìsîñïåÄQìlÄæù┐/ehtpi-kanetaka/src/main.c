#include "tpi_def.h"
#include "circuit.h"
#include "opi.h"
#include "cpi.h"

#define DEBUG 0


int main(argc,argv)
int argc;
char *argv[10];
{
   int ia,ib;
   clock_t t_begin,t_end;
   double run_time;
   t_begin = clock();
//int RANDOM=0;
  if(argc<3){
    printf("error: too less arguments!\n");
    exit(1);
  }

//////////////////////////////
  strcpy(CirName,argv[1]);
  strcpy(out_dir,argv[2]);
//    sprintf(out_dir,"%s/%s/EVAL_DATA/val_COP_%s_cap%d.csv",dir,cir_name,cir_name,Cap);
  	Cap=atoi(argv[3]);
       float cpi_rate;
    if(argv[4]!=NULL){
    cpi_rate=atof(argv[4]);
  }
    else{
      printf("error: please set the ratio of CPs [0.0~0.1]"), exit(1);
    }
     float opi_rate;
    if(argv[5]!=NULL){
     opi_rate=atof(argv[5]);
  }
    else{
        opi_rate=0.0;
      }
///////////////////////////////
  //char oplist_dir[100];
//  sprintf(cop_path,"%s/%s/EVAL_DATA/val_COP_%s_cap%d.csv",dir,cir_name,cir_name,Cap);
printf("============TPI Evaluation Procedure======\nCircuit: %s \nEvaluation Mode: ",argv[1]);
printf("Reading Circuit & Making Netlist\n");
  make_line_list(argv);
printf("Reading Circuit & Making Netlist End\n");

printf("Netlist Sorting\n");
  sort_node();
printf("Netlist Sorting End\n\nGate Levelization Begin\n");
  gate_level();
//c0_1_bias_cal(out_dir,CirName);
//exit(1);

printf("Gate Levelization End\nMax Leve=%d \n",MaxLevel);
#if TP_EVALU_METRIC
  sprintf(cp_path,"%s/CP/%s_%d%d_cost_%d",out_dir,CirName,CAND_EXPLO,CP_ALG,OP_SEL_MODE);
#else
  sprintf(cp_path,"%s/CP/%s_%d%d_%d",out_dir,CirName,CAND_EXPLO,CP_ALG,OP_SEL_MODE);
#endif
cpi_main(cpi_rate,cp_path);
#if STRUCTURE_OP
#if TP_EVALU_METRIC
  sprintf(op_path,"%s/OP/%s_STR_cost",out_dir,CirName);
#else
  sprintf(op_path,"%s/OP/%s_STR",out_dir,CirName);
#endif

#else
#if TP_EVALU_METRIC
    sprintf(op_path,"%s/OP/%s_%d_cost",out_dir,CirName,OP_SEL_MODE);
#else
    sprintf(op_path,"%s/OP/%s_%d",out_dir,CirName,OP_SEL_MODE);
#endif
#endif

opi_main(opi_rate,op_path);

}

void op_set(char *argv[10],float op_rate)
{
  if(atoi(argv[5])==1){
  //fully OPI
  L_NODE *fnode;
  FIN_NODE *finnode;
    finnode=ffnode.next;
    for(; finnode!=NULL; finnode=finnode->next){
      fnode=finnode->node;
        fnode->op_flag=1;
    }
  }
  else if(atoi(argv[5])==2){
  //partial OPI
  char oplist_path[150];
  strcpy(oplist_path,argv[7]);
  L_NODE *fnode;
  FIN_NODE *finnode;

    FILE *fp_opi;
    int ia,opi;
      printf("%d,%f, %d\n",ffnum, op_rate,(int)(ffnum*op_rate));
  fp_opi=fopen(oplist_path,"r");
  printf("oplist=%s\n",oplist_path);
   if(fp_opi==NULL) printf("oplist is not found!\n"), exit(1);
  for(ia=0;ia<(int)(ffnum*op_rate);ia++){
    fscanf(fp_opi,"%d",&opi);
  finnode=ffnode.next;
  for(; finnode!=NULL; finnode=finnode->next){
    fnode=finnode->node;
        if(fnode->op_flag) continue;
    if((fnode->line-inpnum-numout)==opi){
      fnode->op_flag=1;
          //  printf("~|%d,%d|~ ",fnode->line, opi);
      break;
      }
    }
  }
  fclose(fp_opi);
}
else printf("non-OP insertion\n");
}

void cp_set(char *argv[10],float cp_rate)
{
  if(atoi(argv[6])>0){
  //partial OPI
      printf("%d,%f, %d\n",numgate, cp_rate,(int)(numgate*cp_rate));
  char cplist_path[300];
        printf("%s\n\n",argv[8]);
  strcpy(cplist_path,argv[8]);
  L_NODE *fnode;
  FIN_NODE *finnode;
    FILE *fp_cpi;
    int ia,cpi;

  fp_cpi=fopen(cplist_path,"r");
   if(fp_cpi==NULL)
   printf("cplist is not found!\n"), exit(1);
  for(ia=0;ia<(int)(numgate*cp_rate);ia++){
   fscanf(fp_cpi,"%d",&cpi);
  //  printf("*%d ", cpi);
  fnode=gnode.next;
   for( ;fnode!=NULL;fnode=fnode->next){
//printf("-%d  ", fnode->line);
//    if(fnode->cp_flag)  continue;

//    if(fnode->line==8198) printf("found\n\n\n");
    if((fnode->line-inpnum-numout-ffnum)==cpi){
      fnode->cp_flag=1;
     printf("~|%d,%d|~ ",fnode->line, cpi);
      break;
      }
    }
  //  exit(1);
  }
  fclose(fp_cpi);
}
else printf("non-cp insertion\n");
}
