//- C File ------------------------------------------------------------
//
//  File Name    [Preprocess.c]
//
//  System Name  [ff_sel]
//
//  Module Name  [FF_EVAL]
//
//  Author       [Senling Wang]
//
//  Affiliation  [Ehime University]
//
//  Date         [2013]
//
//  Revision     [2016.4.1]
//
//----------------------------------------------------------------------


////////////////////////////////////////////////////////////////////////
//  INCLUDE & MACRO
////////////////////////////////////////////////////////////////////////

#include"tpi_def.h"


//MACROs:
//gate_level(), initiallization(), FF_selection(argv), prn();


////////////////////////////////////////////////////////////////////////
//  VARIABLE & FUNCTION DECLARATIONS
////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////
/// FUNCTION DEFINITIONS
////////////////////////////////////////////////////////////////////////


void OPI_ff_initiallization()
{		// initallize the value of observablity for observation point

 L_NODE *fnode;
  FIN_NODE *finnode;
int ia;
  finnode=ffnode.next;
  for(; finnode!=NULL; finnode=finnode->next){
    fnode=finnode->node;
   if(fnode->op_flag){
     	for(ia=0;ia<=Cap;ia++)
      fnode->O[ia]=1.0;
  }
  }
}

void rm_ff_initiallization()
{		// initallize the value of observablity for observation point

 L_NODE *fnode;
  FIN_NODE *finnode;
int ia;
  finnode=ffnode.next;
  for(; finnode!=NULL; finnode=finnode->next){
    fnode=finnode->node;
   if(!fnode->op_flag){
     	for(ia=0;ia<=Cap;ia++)
      fnode->O[ia]=1.0;
  }
  }

  //gate Initialization
    fnode=gnode.next;
    for( ;fnode!=NULL;fnode=fnode->next){
  	if(fnode->type==PO){
  		for(ia=0;ia<Cap;ia++){
  			fnode->O[ia]=0.0;
      //  fnode->fanNum[ia]=0;
  			}
        //fnode->fanNum[Cap]=0;
  		}
  	else{
  		for(ia=0;ia<Cap;ia++){
  		fnode->O[ia]=-100.0;
      fnode->fanNum[ia+1]=0;
  			}
      //fnode->fanNum[Cap]=0;
   		 }
    //   if(fnode->sel_flag || fnode->cp_flag) printf("[%d, %d %d] ", fnode->line, fnode->sel_flag,fnode->cp_flag);
  	}
}

void CPI_initiallization()
{		// initallize the value of controllablity for Control point

 L_NODE *fnode;
  FIN_NODE *finnode;
int ia;

//PI initiallization
  finnode=pinode.next;
  for(;finnode!=NULL;finnode=finnode->next){
    fnode=finnode->node;
	for(ia=0;ia<Cap;ia++){
 		fnode->C0[ia]=0.5;
 		fnode->C1[ia]=0.5;
 		fnode->O[ia]=0.0;
  //  fnode->fanNum[ia]=0;
		}
	}

//FF initiallization
  finnode=ffnode.next;
  for(; finnode!=NULL; finnode=finnode->next){
    fnode=finnode->node;
  //  if(fnode->sel_flag || fnode->cp_flag  || fnode->op_flag) printf("[ff %d, %d %d] ", fnode->line, fnode->sel_flag,fnode->cp_flag);
#if FF_EXCLUDE
//when FFs are untouchable
 		fnode->C0[0]=-1.0;
 		fnode->C1[0]=-1.0;
		fnode->O[Cap]=0.0;
#else
 		fnode->C0[0]=0.5;
 		fnode->C1[0]=0.5;
		fnode->O[Cap]=1.0;
       for(ia=0;ia<Cap;ia++){
         fnode->fanNum[ia+1]=0;
       }
#endif
  }
//  printf("\n");
//gate Initialization
  fnode=gnode.next;
  for( ;fnode!=NULL;fnode=fnode->next){
	if(fnode->type==PO){
		for(ia=0;ia<Cap;ia++){
			fnode->O[ia]=0.0;
      	fnode->CO[ia]=0;
    //  fnode->fanNum[ia]=0;
			}
      //fnode->fanNum[Cap]=0;
		}
	else{
		for(ia=0;ia<Cap;ia++){
	 	fnode->C0[ia]=-1.0;
 		fnode->C1[ia]=-1.0;
		fnode->O[ia]=-100.0;
    fnode->fanNum[ia+1]=0;
			}
    //fnode->fanNum[Cap]=0;
 		 }
  //   if(fnode->sel_flag || fnode->cp_flag) printf("[%d, %d %d] ", fnode->line, fnode->sel_flag,fnode->cp_flag);
	}
    //printf("\n");
}




void ini_for_trace(){		// initallize the Parameters for logic Tracing

 L_NODE *fnode;
  FIN_NODE *finnode;
//FF initiallization
  finnode=ffnode.next;
  for(; finnode!=NULL; finnode=finnode->next){
    fnode=finnode->node;
    fnode->traced_flag=0;
	   fnode->traced_node_num=0;
	    fnode->fw_traced_node_num=0;
	     fnode->bk_traced_node_num=0;

       fnode->cand_flag=0;
       fnode->sel_flag=0;
  }
//gate Initialization
  fnode=gnode.next;
  for( ;fnode!=NULL;fnode=fnode->next){
     fnode->traced_flag=0;
     fnode->trace_flag=0;
	//fnode->traced_node=(L_NODE *)calloc(numgate+2, sizeof(L_NODE ));
	fnode->traced_node_num=0;
	fnode->fw_traced_node_num=0;
	fnode->bk_traced_node_num=0;
  fnode->cand_flag=0;
  fnode->sel_flag=0;
	}
}



void ini_for_testability(){		// initallize the value of controllablity & observablity

 L_NODE *fnode;
  FIN_NODE *finnode;
  int ia;

//PI initiallization
  finnode=pinode.next;
  for(;finnode!=NULL;finnode=finnode->next){
    fnode=finnode->node;
	for(ia=0;ia<Cap;ia++){
 		fnode->C0[ia]=0.5;
 		fnode->C1[ia]=0.5;
 		fnode->O[ia]=0.0;
    fnode->CC0[ia]=1;
    fnode->CC1[ia]=1;
    fnode->CO[ia]=MUGEN;
		}
	}
//FF initiallization
  finnode=ffnode.next;
  for(; finnode!=NULL; finnode=finnode->next){
    fnode=finnode->node;
#if FF_EXCLUDE
//when FFs are untouchable
 		fnode->C0[0]=-1.0;
 		fnode->C1[0]=-1.0;
		fnode->O[Cap]=0;

#else
 		fnode->C0[0]=0.5;
 		fnode->C1[0]=0.5;
		fnode->O[Cap]=1.0;
 		fnode->CC0[0]=1;
 		fnode->CC1[0]=1;
 		fnode->CO[Cap]=0;
#endif
  }
//gate Initialization
  fnode=gnode.next;
  for( ;fnode!=NULL;fnode=fnode->next){
	if(fnode->type==PO){
		for(ia=0;ia<Cap;ia++){
			fnode->O[ia]=0.0;
 			fnode->CO[ia]=0;
			}
		}
	else{
		for(ia=0;ia<Cap;ia++){
	 	fnode->C0[ia]=-1.0;
 		fnode->C1[ia]=-1.0;
		fnode->O[ia]=-100.0;
 		fnode->CO[ia]=MUGEN;
			}
 		 }
	}
}


void initiallization(){		// initallize the value of controllablity & observablity

 L_NODE *fnode;
  FIN_NODE *finnode;
  int ia;

//PI initiallization
  finnode=pinode.next;
  for(;finnode!=NULL;finnode=finnode->next){
    fnode=finnode->node;

	for(ia=0;ia<Cap;ia++){
 		fnode->C0[ia]=0.5;
 		fnode->C1[ia]=0.5;
 		fnode->O[ia]=0.0;
 		fnode->CC0[ia]=1;
 		fnode->CC1[ia]=1;
 		fnode->CO[ia]=MUGEN;
		}
	}
//FF initiallization
  finnode=ffnode.next;
  for(; finnode!=NULL; finnode=finnode->next){
    fnode=finnode->node;
    fnode->cand_flag=0;
    fnode->sel_flag=0;
     fnode->op_flag=0;
     fnode->traced_flag=0;
	fnode->traced_node_num=0;
	fnode->fw_traced_node_num=0;
	fnode->bk_traced_node_num=0;

#if FF_EXCLUDE
//when FFs are untouchable
 		fnode->C0[0]=-1.0;
 		fnode->C1[0]=-1.0;
		fnode->O[Cap]=0;

#else
 		fnode->C0[0]=0.5;
 		fnode->C1[0]=0.5;
		fnode->O[Cap]=1.0;
 		fnode->CC0[0]=1;
 		fnode->CC1[0]=1;
 		fnode->CO[Cap]=0;
#endif
  }
//gate Initialization
  fnode=gnode.next;
  for( ;fnode!=NULL;fnode=fnode->next){
     fnode->cand_flag=0;
     fnode->sel_flag=0;
    fnode->cp_flag=0;
     fnode->traced_flag=0;
     fnode->trace_flag=0;
	for(ia=0;ia<6;ia++) fnode->tgl_gt_cnt[ia]=0;
	//fnode->traced_node=(L_NODE *)calloc(numgate+2, sizeof(L_NODE ));
	fnode->traced_node_num=0;
	fnode->fw_traced_node_num=0;
	fnode->bk_traced_node_num=0;

	if(fnode->type==PO){
		for(ia=0;ia<Cap;ia++){
			fnode->O[ia]=0.0;
 			fnode->CO[ia]=0;
			}
		}
	else{
		for(ia=0;ia<Cap;ia++){
	 	fnode->C0[ia]=-1.0;
 		fnode->C1[ia]=-1.0;
		fnode->O[ia]=-100.0;
 		fnode->CO[ia]=MUGEN;
			}
 		 }
	}

}



void initiallization_2(){		// initallize the value of controllablity & observablity

 L_NODE *fnode;
  FIN_NODE *finnode;
  int ia,flag,tmplevl,gate_count=0;

  finnode=pinode.next;
  for(;finnode!=NULL;finnode=finnode->next){
    fnode=finnode->node;
	for(ia=0;ia<=Cap;ia++){
 		fnode->C0[ia]=0.5;
 		fnode->C1[ia]=0.5;
 		fnode->O[ia]=0.0;
 		fnode->CC0[ia]=1;
 		fnode->CC1[ia]=1;
 		fnode->CO[ia]=MUGEN;
		}
	}

  finnode=ffnode.next;
  for(; finnode!=NULL; finnode=finnode->next){
    fnode=finnode->node;
    fnode->cand_flag=0;
    fnode->sel_flag=0;
     fnode->traced_flag=0;
	fnode->traced_node_num=0;
	fnode->fw_traced_node_num=0;
	fnode->bk_traced_node_num=0;

	for(ia=0;ia<=Cap;ia++){
 		fnode->C0[ia]=-1.0;
 		fnode->C1[ia]=-1.0;
		fnode->O[ia]=0.0;
		}
#if FF_EXCLUDE
 		fnode->C0[0]=-1.0;
 		fnode->C1[0]=-1.0;
		fnode->O[Cap]=1.0;

#else
 		fnode->C0[0]=0.5;
 		fnode->C1[0]=0.5;
		fnode->O[Cap]=1.0;
 		fnode->CC0[0]=1;
 		fnode->CC1[0]=1;
 		fnode->CO[Cap]=0;
#endif
  }

  fnode=gnode.next;
  for( ;fnode!=NULL;fnode=fnode->next){

    fnode->cand_flag=0;
    fnode->sel_flag=0;
     fnode->traced_flag=0;
     fnode->trace_flag=0;
	for(ia=0;ia<6;ia++) fnode->tgl_gt_cnt[ia]=0;
	//fnode->traced_node=(L_NODE *)calloc(numgate+2, sizeof(L_NODE ));
	fnode->traced_node_num=0;
	fnode->fw_traced_node_num=0;
	fnode->bk_traced_node_num=0;

	if(fnode->type==PO){
		for(ia=0;ia<=Cap;ia++){
			fnode->O[ia]=0.0;
 			fnode->CO[ia]=0;
			}
		}
	else{
		for(ia=0;ia<=Cap;ia++){
	 	fnode->C0[ia]=-1.0;
 		fnode->C1[ia]=-1.0;
		fnode->O[ia]=-100.0;
 		fnode->CO[ia]=MUGEN;
			}
 		 }
	}

}
