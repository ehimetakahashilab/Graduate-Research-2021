#include"opi.h"
#include"cpi.h"
//void full_ob_setting();
//CP approaches: 11, 12, 13, 21, 221, 23

//int nodes[10000];
void op_prn()
{
  L_NODE *fnode;
  FIN_NODE *finnode;
  int cnt=0;
  finnode=ffnode.next;
   for(; finnode!=NULL; finnode=finnode->next){
          fnode=finnode->node;
          #if OP_SEL_MODE==1
            if(!fnode->op_flag){
          #elif OP_SEL_MODE==2
            if(fnode->op_flag){
         #endif
            cnt++;
          printf("[%d: %d->%d ]",cnt,fnode->line-inpnum-numout, fnode->op_flag);
        }
 }
}
void create_stuct_val_table(double **val_table){
  L_NODE *fnode;
  FIN_NODE *finnode;
  finnode = ffnode.next;
  for (int iff = 0; finnode != NULL; finnode = finnode->next, iff++) {
    fnode = finnode->node;
    val_table[iff][0]=
            (float)fnode->arrive_branch / fnode->total_branch;
    val_table[iff][1]= fnode->TYPE[0];
    val_table[iff][2]=fnode->TYPE[1];
    val_table[iff][3]= fnode->TYPE[2];
    val_table[iff][4]= fnode->eval_C[7];
  }
}
#if OP_SEL_MODE==1
//exploring the candidate ops by increasment order, smaller the evaluate value to larger
int explor_candi_op_by_topsis(L_NODE *candi_list[])
{
int ia,cnd_cnt=0;
L_NODE *fnode;
FIN_NODE *finnode;

float minval=99999.0;
   printf("candinate OP List\n");
cnd_cnt=0;
for(ia=0;ia<OP_CANDI_NUM;ia++){
     minval=1.0;
     int flag=0;

   finnode=ffnode.next;
    for(; finnode!=NULL; finnode=finnode->next){
       fnode=finnode->node;         //printf("^%d,%f,%d,%d ^ \n",fnode->line,fnode->op_val,fnode->cand_flag,fnode->op_flag);

       if(fnode->cand_flag||(!fnode->op_flag)) continue;
    //if(fnode->line==127)  printf("^%d,%f^ ",fnode->line,fnode->contri[0]),exit(1);

       if(fnode->op_val<=minval){
          minval=fnode->op_val;
          candi_list[ia]=fnode;
             flag++;
        }
    }

    if(flag) {
      candi_list[cnd_cnt]->cand_flag=1;
      cnd_cnt++;
  //  printf("hererh ia %d, flag=%d\n",ia,flag);
    printf("%d %d,%d %f\n",ia,cnd_cnt,candi_list[cnd_cnt-1]->line,candi_list[cnd_cnt-1]->op_val);
  }
  }
     printf("\n");
     return cnd_cnt;
}
#elif OP_SEL_MODE==2
//exploring the candidate ops by decreasment order, larger the evaluate value to smaller
int explor_candi_op_by_topsis(L_NODE *candi_list[])
{
int ia,cnd_cnt=0;
L_NODE *fnode;
FIN_NODE *finnode;
float maxval;
   printf("candinate OP List\n");
cnd_cnt=0;
for(ia=0;ia<OP_CANDI_NUM;ia++){
     maxval=0.0;
     int flag=0;

   finnode=ffnode.next;
    for(; finnode!=NULL; finnode=finnode->next){
       fnode=finnode->node;         //printf("^%d,%f^ ",fnode->line,fnode->op_val);
       if(fnode->cand_flag||fnode->op_flag) continue;
    //if(fnode->line==127)  printf("^%d,%f^ ",fnode->line,fnode->contri[0]),exit(1);
       if(fnode->op_val>=maxval){
          maxval=fnode->op_val;
          candi_list[ia]=fnode;
             flag++;
        }
    }

    if(flag) {
      candi_list[cnd_cnt]->cand_flag=1;
      cnd_cnt++;
  }
    printf("%d %d,%d %f\n",ia,cnd_cnt,candi_list[cnd_cnt-1]->line,candi_list[cnd_cnt-1]->op_val);
  }
     printf("\n");
     return cnd_cnt;
}
#endif

void opi_main(float op_rate,char *op_path)
{
  clock_t t_begin, t_end;
  double run_time;
  t_begin = clock();

  printf("Ranking the FF list by Structure Based Evaluation: BRANCH, TOGGLE_PRO, COMPLEX, TYPE");
  printf(
      "Stucture Based Evaluation Begin\nTrace Process Initializatio Begin\n");

  trace_initial(gnode.next, ffnode.next);

  printf(
      "\nTrace Process Initializatio End\nForward Tracing from gate Begin\n");

  gt_forw_trace(gnode.next);

  printf(
      "\nForward Tracing from gate End\nBack Tracing from gate Begin\n");  // exit(1);

  gt_back_trace(gnode.next);

  printf(
      "\nBack Tracing from gate End\nForward Tracing from FF Begin\n");  // exit(1);

  ff_forw_trace(ffnode.next);

  printf(
      "\nForward Tracing from FF End\nBack Tracing from FF Begin\n");  // exit(1);

  ff_back_trace(ffnode.next);

  printf("\nBack Tracing from FF End\nTYPE1-3 Computation Begin\n");

  type1_3(gnode.next, ffnode.next);

  printf("\nTYPE1-3 Computation End\n");

  printf("\nStucture Based Evaluation End\n");

  t_end = clock();
  run_time = (double)(t_end - t_begin) / CLOCKS_PER_SEC;
  printf("Structure Analizing Time:%.4lf[sec]\n", run_time);

  double **struct_val;
  struct_val = (double **)calloc(ffnum + 1, sizeof(double *));
  if (struct_val == NULL) printf("error:'structure value table ' is not created\n"), exit(1);
  for (int ia = 0; ia < ffnum + 1; ia++)
    struct_val[ia] = (double *)calloc(STRUCT_TERMS, sizeof(double));
  create_stuct_val_table(struct_val);
  topsis_cal(struct_val,STRUCT_TERMS);


  //printf("gate Tracing for structure info\n");
  printf("Parameter Initialization Begin\n");
  ini_for_testability();
 //ini_for_trace();
  printf("Initialization End\nOP Removing process start\n");

  //gt_forw_trace_for_cpi(gnode.next);
  FILE *fout;
    fout=fopen(op_path,"w");
  if(fout==NULL) printf("op_list file is not exist, check it!\n"), exit(1);
    int ia=0,i_op=0;
    int OP_NUM=op_rate*ffnum;

 printf("Expect OPNUM=%d : %f x %d\n",OP_NUM, op_rate,ffnum);

 #if STRUCTURE_OP
 topsis_rank_prn(1, fout);
 #else
/*
    L_NODE **op_lists;
    op_lists = (L_NODE **)calloc(OP_NUM, sizeof(L_NODE *));
    L_NODE **candi_list;
    candi_list = (L_NODE **)calloc(OP_CANDI_NUM, sizeof(L_NODE *));
*/


  L_NODE **op_lists;
  op_lists = (L_NODE **)calloc(OP_NUM, sizeof(L_NODE *));
  L_NODE **candi_list;
  candi_list = (L_NODE **)calloc(OP_CANDI_NUM+1, sizeof(L_NODE *));

  CP_NUM=0.01*numgate;
  cp_setting(cp_path, CP_NUM);// CP listを読み込んで、cpとして設定する

#if OP_SEL_MODE==1
/*:::::全観測設定：：：：：：：：：：：：：*///
  full_ob_setting();//すべてのＦＦを観測できるように設定する
#endif

  CPI_initiallization();
   printf("~Controllablity Computing start\n");
  // exit(1);
   for (ia=0; ia < Cap; ia++) {
     COP_C(ia);
   }
  printf("~Controllablity Computing End\n");
  printf("~Observability Computing start\n");
  for(ia=Cap;ia>0;ia--){
    COP_O(ia);

    }
  printf("~Observability Computing End\n");

  printf("exfc original %f ",exp_fc_cal_per_pat(PATNUM));
//  exit(1);
/*推定故障検出率に最も影響しないFFを抜かす*/

#if OP_SEL_MODE==1
int target_OP_num=ffnum-OP_NUM;
#elif OP_SEL_MODE==2
int target_OP_num=OP_NUM;
#endif

    while(i_op<target_OP_num){
 printf("@# %d / %d OP selection \n",i_op+1,ffnum-OP_NUM);
  op_prn();
  printf("\n");
 int aviable_op_num=0;
 //do{
   aviable_op_num=explor_candi_op_by_topsis(candi_list);
 //}while (aviable_op_num);
 printf("\n@#%d / %d OP selection: 有効OP:%d/%d \n",i_op+1,target_OP_num,aviable_op_num,OP_CANDI_NUM );
  if(aviable_op_num) {
// int target_op=rm_one_op_by_expfc(candi_list,aviable_op_num);
#if TP_EVALU_METRIC
 int target_op=pull_one_op_by_cost(candi_list,aviable_op_num);
#else
 int target_op=rm_one_op_by_expfc(candi_list,aviable_op_num);
#endif

 if (target_op>0){
   i_op++;
   printf("pull %d ff \n",target_op-inpnum-numout);
   //fprintf(fout,"%d\n",target_op-inpnum-numout);
  refresh_all_opnode();
  }
  else {
    printf("#%d OP is not determine yet, continute...\n",i_op+1);
    if(ff_routing_check()==0){
    printf("all ff nodes have been checked, not additional suitable op was found\n OP Removing will be ended here\n");
    printf("pull OP number = %d\n ",i_op+1);
    break;
    }
 //exit(1);
    }
  }
else{
    printf("@#%d OP selection: 有効なOPが見つかりませんでした！Check other FFs!\n",i_op+1);
    if(ff_routing_check()==0){
    printf("all ff nodes have been checked, not additional suitable op was found\n OP Removing will be ended here\n");
    printf("pull OP number = %d\n ",i_op+1);
    break;
    }
}

}


  L_NODE *fnode;
  FIN_NODE *finnode;
  finnode=ffnode.next;
   for(; finnode!=NULL; finnode=finnode->next){
      fnode=finnode->node;        // printf("^%d,%d^ ",fnode->line,fnode->cand_flag);
    if( fnode->op_flag)
    fprintf(fout,"%d\n",fnode->line-inpnum-numout);
    }
//free(candi_list);
#endif
fclose(fout);
//free(cp_lists);
}
#if OP_SEL_MODE==1
int ff_routing_check(){
  L_NODE *fnode;
  FIN_NODE *finnode;
  int flag=0;

  finnode=ffnode.next;
   for(; finnode!=NULL; finnode=finnode->next){
      fnode=finnode->node;         //printf("^%d,%d^ ",fnode->line,fnode->cand_flag);
      if(!fnode->op_flag) continue;
      if(!fnode->cand_flag) {flag=1;break;}
    }
    printf("routing check\n");
if(flag) return -1;
else return 0;
}
#elif OP_SEL_MODE==2
int ff_routing_check(){
  L_NODE *fnode;
  FIN_NODE *finnode;
  int flag=0;

  finnode=ffnode.next;
   for(; finnode!=NULL; finnode=finnode->next){
      fnode=finnode->node;        // printf("^%d,%d^ ",fnode->line,fnode->cand_flag);
      if(fnode->op_flag) continue;
      if(!fnode->cand_flag) {flag=1;break;}
    }
    printf("routing check\n");
if(flag) return -1;
else return 0;
}
#endif

void refresh_all_opnode(){
  L_NODE *fnode;
  FIN_NODE *finnode;
  finnode=ffnode.next;
   for(; finnode!=NULL; finnode=finnode->next){
      fnode=finnode->node;         // printf("^%d,%d^ ",fnode->line,fnode->cand_flag);
      fnode->cand_flag=0;
    }
}


void cp_setting(char *cp_path, int cp_num)
{
  FILE *file_cp;
  printf("reading cplist from %s \n", cp_path);
  file_cp = fopen(cp_path,"r");

  if (file_cp == NULL){
    fprintf(stderr, "file 'cplist' can`t open\n"), exit(1);
  }
    int cpi;
    L_NODE *fnode;
    FIN_NODE *finnode;
  for (int ia = 0; ia < cp_num; ia++){
    fscanf(file_cp, "%d\n", &cpi);

    finnode=ffnode.next;
    for(; finnode!=NULL; finnode=finnode->next){
      fnode=finnode->node;
      if(fnode->cp_flag)  continue;
      if((fnode->line-inpnum-numout-ffnum)==cpi){
         fnode->cp_flag=1;
         printf("~|ff %d,%d|~ ",fnode->line, cpi);
         break;
        }
      }
    fnode=gnode.next;
     for( ;fnode!=NULL;fnode=fnode->next){
     if(fnode->cp_flag)  continue;
     if((fnode->line-inpnum-numout-ffnum)==cpi){
        fnode->cp_flag=1;
        printf("~|%d,%d|~ ",fnode->line, cpi);
        break;
        }
      }
    }
  fclose(file_cp);
}

int rm_one_op_by_expfc(L_NODE **candi_list,int aviable_op_num)
{
  int ia,ib;
double exfc_orig=0.0;
double exfc_new=0.0, exfc_delta_max=0.0;
L_NODE *tmp_node;
int node_num=-1;
exfc_orig=exp_fc_cal_per_pat(PATNUM);
 exfc_delta_max=FCOV_DECREMENT_BOUND;
printf("exfc original %f ",exfc_orig);
//exit(1);
for(ia=0;ia<aviable_op_num;ia++){
    //       printf("HERRE?\n");
    //     printf("Start cand %d ff %d, lost:%f\n",ia,candi_list[ia]->line,exfc_orig-exfc_new);
  if(!candi_list[ia]->op_flag) {
    printf("Yes %d %d\n", candi_list[ia]->line,candi_list[ia]->op_flag);
    continue;
  }
  candi_list[ia]->op_flag = 0;

//  for(ib=0;ib<Cap;ib++){
//   candi_list[ia]->O[ib]=-1.0;
//   }
// candi_list[ia]->O[Cap]=1.0;
   //rm_ff_initiallization();
    for(ib=Cap;ib>0;ib--){
      COP_O(ib);
    }
    exfc_new=exp_fc_cal_per_pat(PATNUM);
    printf("exfc original %f ",exfc_orig);printf("->%f\n",exfc_new);
       printf("cand %d ff %d, lost:%f\n",ia,candi_list[ia]->line,exfc_orig-exfc_new);
    if((exfc_orig-exfc_new)<exfc_delta_max){
      exfc_delta_max=exfc_new-exfc_orig;
      tmp_node=candi_list[ia];
      node_num=candi_list[ia]->line;
    }
   candi_list[ia]->op_flag = 1;
//  for(ib=0;ib<=Cap;ib++){
//   candi_list[ia]->O[ib]=1.0;
//  }

}
   if(node_num>0){
  //  if(node_num)  sel_cp_num++;
    tmp_node->op_flag=0;
  //  for(ib=0;ib<Cap;ib++){
  //    tmp_node->O[ib]=-1.0;
  //  }
    printf("selected node: %d \n",tmp_node->line);
    for(ib=Cap;ib>0;ib--){
      COP_O(ib);
    }
    return node_num;
  }
  else {
    return -1;
  }
}

#if OP_SEL_MODE==1
//remove one op with the smallest cost increase from the candidate ops
int pull_one_op_by_cost(L_NODE **candi_list,int aviable_op_num)
{
  int ia,ib;
  long long int cost_orig,cost_new;
  long long int cost_delta_min;
  //double cost_orig,cost_new;
  //double cost_delta_min;
L_NODE *tmp_node;
int node_num=-1;
  cost_orig=cost_func_cal();
  cost_delta_min=0;
//    cost_delta_min=0.0;

//exit(1);
for(ia=0;ia<aviable_op_num;ia++){
    //       printf("HERRE?\n");
    //     printf("Start cand %d ff %d, lost:%f\n",ia,candi_list[ia]->line,exfc_orig-exfc_new);
  if(!candi_list[ia]->op_flag) {
    printf("Yes %d %d\n", candi_list[ia]->line,candi_list[ia]->op_flag);
    continue;
  }
  candi_list[ia]->op_flag = 0;

    for(ib=Cap;ib>0;ib--){
      COP_O(ib);
    }
    cost_new=cost_func_cal();
//   printf("original cost %f ",cost_orig);printf("->%f\n",cost_new);
//          printf("cand %d ff %d, lost:%f\n",ia,candi_list[ia]->line,cost_orig-cost_new);
      printf("original cost %lld ",cost_orig);printf("->%lld\n",cost_new);
         printf("cand %d ff %d, lost:%lld\n",ia,candi_list[ia]->line,cost_orig-cost_new);
    if((cost_orig-cost_new)>=cost_delta_min){
      cost_delta_min=cost_orig-cost_new;
      tmp_node=candi_list[ia];
      node_num=candi_list[ia]->line;
    }
   candi_list[ia]->op_flag = 1;
//  for(ib=0;ib<=Cap;ib++){
//   candi_list[ia]->O[ib]=1.0;
//  }

}
   if(node_num>0){
  //  if(node_num)  sel_cp_num++;
    tmp_node->op_flag=0;
  //  for(ib=0;ib<Cap;ib++){
  //    tmp_node->O[ib]=-1.0;
  //  }
    printf("selected node: %d \n",tmp_node->line);
    for(ib=Cap;ib>0;ib--){
      COP_O(ib);
    }
    return node_num;
  }
  else {
    return -1;
  }
}
#elif OP_SEL_MODE==2
//pull one op with largest cost reduction from the candidate ops
int pull_one_op_by_cost(L_NODE **candi_list,int aviable_op_num)
{
  int ia,ib;
  long long int cost_orig,cost_new;
  long long int cost_delta_min;
  //double cost_orig,cost_new;
  //double cost_delta_min;
L_NODE *tmp_node;
int node_num=-1;
  cost_orig=cost_func_cal();
  cost_delta_min=0;
//    cost_delta_min=0.0;

//exit(1);
for(ia=0;ia<aviable_op_num;ia++){
    //       printf("HERRE?\n");
    //     printf("Start cand %d ff %d, lost:%f\n",ia,candi_list[ia]->line,exfc_orig-exfc_new);
  if(candi_list[ia]->op_flag) {
    printf("Yes %d %d\n", candi_list[ia]->line,candi_list[ia]->op_flag);
    continue;
  }
  candi_list[ia]->op_flag = 1;

    for(ib=Cap;ib>0;ib--){
      COP_O(ib);
    }
    cost_new=cost_func_cal();
//   printf("original cost %f ",cost_orig);printf("->%f\n",cost_new);
//          printf("cand %d ff %d, lost:%f\n",ia,candi_list[ia]->line,cost_orig-cost_new);
      printf("original cost %ld ",cost_orig);printf("->%ld\n",cost_new);
         printf("cand %d ff %d, cost reduction:%ld\n",ia,candi_list[ia]->line,cost_orig-cost_new);
    if((cost_orig-cost_new)>=cost_delta_min){
      cost_delta_min=cost_orig-cost_new;
      tmp_node=candi_list[ia];
      node_num=candi_list[ia]->line;
    }
   candi_list[ia]->op_flag = 0;
//  for(ib=0;ib<=Cap;ib++){
//   candi_list[ia]->O[ib]=1.0;
//  }

}
   if(node_num>0){
  //  if(node_num)  sel_cp_num++;
    tmp_node->op_flag=1;
  //  for(ib=0;ib<Cap;ib++){
  //    tmp_node->O[ib]=-1.0;
  //  }
    printf("selected node: %d \n",tmp_node->line);
    for(ib=Cap;ib>0;ib--){
      COP_O(ib);
    }
    return node_num;
  }
  else {
    return -1;
  }

}
#endif


void topsis_cal(double **eval_val,int TermNum){
  int ia, ib, W = 0, FFId = 0;
  double EvaTermSqrt[TermNum];
  double Weight[TermNum], BestWorstCase[TermNum][2];
  double MaxTD, ToGoodCase[ffnum], ToBadCase[ffnum], ExpectTopSisValue[ffnum];
  int term_var_check[TermNum];
  printf("%d\n", TermNum);
  for (ia = 0; ia < ffnum; ia++) {
    printf("%d: ", ia + 1);
    for (ib = 0; ib < TermNum; ib++) printf("%4f ", eval_val[ia][ib]);
    printf("\n");
  }

  printf("Initializing: ");
  // printf("%d ",ia);
  for (ib = 0; ib < TermNum; ib++) {
    term_var_check[ib]=1;
    EvaTermSqrt[ib] = 0.0;
    Weight[ib] = 0.0;
    W++;
    // printf("%.15f ",eval_val[ia][ib]);
  }
  printf(" End \nTerm Number =%d, Weight = %d\n", TermNum, W);

  printf("\n---Matrix Normalization Beging: \n");
  /*Matrix Normalization*/
  for (ia = 0; ia < TermNum; ia++) {
    for (ib = 0; ib < ffnum; ib++) {
      EvaTermSqrt[ia] += (double)eval_val[ib][ia] * eval_val[ib][ia];
    }
    EvaTermSqrt[ia] = sqrt((float)EvaTermSqrt[ia]);
    if(EvaTermSqrt[ia]==0.0) {term_var_check[ia]=0; W--;}
  }

  for (ia = 0; ia < TermNum; ia++) {
            Weight[ia] = (float)1 / W;
            printf(" %d %d %f %f %d \n", ia,term_var_check[ia],  EvaTermSqrt[ia],Weight[ia], W);
          }

  for (ia = 0; ia < ffnum; ia++) {
    // printf("\n%d ",ia);
    for (ib = 0; ib < TermNum; ib++) {
      if(term_var_check[ib])
      eval_val[ia][ib] /= ((double)EvaTermSqrt[ib] / Weight[ib]);
      // printf("%f ",eval_val[ia][ib]);
    }
    // printf("\n");
  }
  printf("End\n");

  /*Best and worst case computation*/
  /*
  BestWorstCase[ia][0]: Best case
  BestWorstCase[ia][1]: Worst Case

  TREND=
  0: disable evaluation, >0: enable evaluation
  -1: the smaller the better
  1: the larger the better
  */

  printf("\n---Best-Worst case computation Begin::\n");
  for (ia = 0; ia < TermNum; ia++) {
    if(!term_var_check[ia]) continue;
    switch (TREND) {
      case 0: printf("Topsis evaluation is not aviable\n"), exit(1);
      case -1:
        BestWorstCase[ia][0] = eval_val[0][ia];
        BestWorstCase[ia][1] = eval_val[0][ia];
        for (ib = 0; ib < ffnum; ib++) {  // printf("%f ",eval_val[ib][ia]);
          if (eval_val[ib][ia] < BestWorstCase[ia][0])
            BestWorstCase[ia][0] = eval_val[ib][ia];
          if (eval_val[ib][ia] > BestWorstCase[ia][1])
            BestWorstCase[ia][1] = eval_val[ib][ia];
        }
        break;
      case 1:
        BestWorstCase[ia][0] = eval_val[0][ia];
        BestWorstCase[ia][1] = eval_val[0][ia];
        for (ib = 0; ib < ffnum; ib++) {  // printf("%f ",eval_val[ib][ia]);
          if (eval_val[ib][ia] > BestWorstCase[ia][0])
            BestWorstCase[ia][0] = eval_val[ib][ia];
          if (eval_val[ib][ia] < BestWorstCase[ia][1])
            BestWorstCase[ia][1] = eval_val[ib][ia];
        }
        break;
      default:
        break;
    }
    printf(" Term%d: %f %f", ia, BestWorstCase[ia][0], BestWorstCase[ia][1]);
  }
  printf("\n---Best-Worst case computation End\n");

  /*distance computation*/
  printf("\n---Distance computation Begin::\n");
  for (ia = 0; ia < ffnum; ia++) {
    ToGoodCase[ia] = 0.0;
    ToBadCase[ia] = 0.0;
   ExpectTopSisValue[ia] = 0.0;
    for (ib = 0; ib < TermNum; ib++) {
      if(!term_var_check[ib]) continue;
      ToGoodCase[ia] += (BestWorstCase[ib][0] - eval_val[ia][ib]) *
                        (BestWorstCase[ib][0] - eval_val[ia][ib]);
      ToBadCase[ia] += (eval_val[ia][ib] - BestWorstCase[ib][1]) *
                       (eval_val[ia][ib] - BestWorstCase[ib][1]);
    }
    ToGoodCase[ia] = sqrt((float)ToGoodCase[ia]);
    ToBadCase[ia] = sqrt((float)ToBadCase[ia]);

    ExpectTopSisValue[ia] =
        (float)ToBadCase[ia] / (ToBadCase[ia] + ToGoodCase[ia]);
    printf("%d->%f ", ia + 1, ExpectTopSisValue[ia]);
    if (ia % 10 == 0) printf("\n");
  }
  printf("\n---distance computation End\n");
//topsis_rank_prn(ExpectTopSisValue,1);
  /*TopSis Base Selection*/
//exit(1);
 copy_back(ExpectTopSisValue);

//exit(1);
}


int topsis_cal_gener(double **eval_val,int TermNum, int member){
  int ia, ib, W = 0, FFId = 0;
  double EvaTermSqrt[TermNum];
  double Weight[TermNum], BestWorstCase[TermNum][2];
  double MaxTD, ToGoodCase[member], ToBadCase[member], ExpectTopSisValue[member];
  int term_var_check[TermNum];
  printf("%d\n", TermNum);
  for (ia = 0; ia < member; ia++) {
    printf("%d: ", ia + 1);
    for (ib = 0; ib < TermNum; ib++) printf("%4f ", eval_val[ia][ib]);
    printf("\n");
  }

  printf("Initializing: ");
  // printf("%d ",ia);
  for (ib = 0; ib < TermNum; ib++) {
    term_var_check[ib]=1;
    EvaTermSqrt[ib] = 0.0;
    Weight[ib] = 0.0;
    W++;
    // printf("%.15f ",eval_val[ia][ib]);
  }
  printf(" End \nTerm Number =%d, Weight = %d\n", TermNum, W);

  printf("\n---Matrix Normalization Beging: \n");
  /*Matrix Normalization*/
  for (ia = 0; ia < TermNum; ia++) {
    for (ib = 0; ib < member; ib++) {
      EvaTermSqrt[ia] += (double)eval_val[ib][ia] * eval_val[ib][ia];
    }
    EvaTermSqrt[ia] = sqrt((float)EvaTermSqrt[ia]);
    if(EvaTermSqrt[ia]==0.0) {term_var_check[ia]=0; W--;}
  }

  for (ia = 0; ia < TermNum; ia++) {
            Weight[ia] = (float)1 / W;
            printf(" %d %d %f %f %d \n", ia,term_var_check[ia],  EvaTermSqrt[ia],Weight[ia], W);
          }

  for (ia = 0; ia < member; ia++) {
    // printf("\n%d ",ia);
    for (ib = 0; ib < TermNum; ib++) {
      if(term_var_check[ib])
      eval_val[ia][ib] /= ((double)EvaTermSqrt[ib] / Weight[ib]);
      // printf("%f ",eval_val[ia][ib]);
    }
    // printf("\n");
  }
  printf("End\n");

  /*Best and worst case computation*/
  /*
  BestWorstCase[ia][0]: Best case
  BestWorstCase[ia][1]: Worst Case

  TREND=
  0: disable evaluation, >0: enable evaluation
  -1: the smaller the better
  1: the larger the better
  */
int direction[3]={1,1,-1};
  printf("\n---Best-Worst case computation Begin::\n");
  for (ia = 0; ia < TermNum; ia++) {
    if(!term_var_check[ia]) continue;
    switch (direction[ia]) {
      case 0: printf("Topsis evaluation is not aviable\n"), exit(1);
      case -1:
        BestWorstCase[ia][0] = eval_val[0][ia];
        BestWorstCase[ia][1] = eval_val[0][ia];
        for (ib = 0; ib < member; ib++) {  // printf("%f ",eval_val[ib][ia]);
          if (eval_val[ib][ia] < BestWorstCase[ia][0])
            BestWorstCase[ia][0] = eval_val[ib][ia];
          if (eval_val[ib][ia] > BestWorstCase[ia][1])
            BestWorstCase[ia][1] = eval_val[ib][ia];
        }
        break;
      case 1:
        BestWorstCase[ia][0] = eval_val[0][ia];
        BestWorstCase[ia][1] = eval_val[0][ia];
        for (ib = 0; ib < member; ib++) {  // printf("%f ",eval_val[ib][ia]);
          if (eval_val[ib][ia] > BestWorstCase[ia][0])
            BestWorstCase[ia][0] = eval_val[ib][ia];
          if (eval_val[ib][ia] < BestWorstCase[ia][1])
            BestWorstCase[ia][1] = eval_val[ib][ia];
        }
        break;
      default:
        break;
    }
    printf(" Term%d: %f %f", ia, BestWorstCase[ia][0], BestWorstCase[ia][1]);
  }
  printf("\n---Best-Worst case computation End\n");

  /*distance computation*/
  printf("\n---Distance computation Begin::\n");
  double eval_max=0.0; int max_member=-1;
  for (ia = 0; ia < member; ia++) {
    ToGoodCase[ia] = 0.0;
    ToBadCase[ia] = 0.0;
   ExpectTopSisValue[ia] = 0.0;
    for (ib = 0; ib < TermNum; ib++) {
      if(!term_var_check[ib]) continue;
      ToGoodCase[ia] += (BestWorstCase[ib][0] - eval_val[ia][ib]) *
                        (BestWorstCase[ib][0] - eval_val[ia][ib]);
      ToBadCase[ia] += (eval_val[ia][ib] - BestWorstCase[ib][1]) *
                       (eval_val[ia][ib] - BestWorstCase[ib][1]);
    }
    ToGoodCase[ia] = sqrt((float)ToGoodCase[ia]);
    ToBadCase[ia] = sqrt((float)ToBadCase[ia]);

    ExpectTopSisValue[ia] =
        (float)ToBadCase[ia] / (ToBadCase[ia] + ToGoodCase[ia]);
        if(ExpectTopSisValue[ia]>=eval_max){
           max_member=ia;
           eval_max=ExpectTopSisValue[ia];
        }
    printf("%d->%f ", ia + 1, ExpectTopSisValue[ia]);
    if (ia % 10 == 0) printf("\n");
  }
  printf("\n---distance computation End\n");
  return max_member;
//topsis_rank_prn(ExpectTopSisValue,1);
  /*TopSis Base Selection*/
//exit(1);
 //copy_back(ExpectTopSisValue);

//exit(1);
}


void topsis_rank_prn(int direct,FILE *fout)
{
  int ia, FF_Id, iNum;
  double Max, Min;
  double eval[ffnum];
  int flag[ffnum];

  L_NODE *fnode;
  FIN_NODE *finnode;
  finnode=ffnode.next;
   for(int iff=0; finnode!=NULL; finnode=finnode->next,iff++){
          fnode=finnode->node;
        eval[iff]=fnode->op_val;
          //printf("~%d %f %f~ ",fnode->line, fnode->op_val,eval[iff]);
   }


 for (ia = 0; ia < ffnum; ia++) {
   flag[ia]=-1;
      // printf("%d, %f\n", ia + 1, eval[ia]);
 }
 //exit(1);
  iNum = ffnum;
  while (iNum > 0) {
    Max = 0.0;
    FF_Id = -1;
    Min = 999999.0;
    for (ia = 0; ia < ffnum; ia++) {
      if (flag[ia] == 0) continue;
      if (direct == 1) {
        if (eval[ia] >= Max) {
          Max = eval[ia];
          FF_Id = ia;
        }
      } else if (direct == -1) {
        if (eval[ia] <= Min) {
          Min = eval[ia];
          FF_Id = ia;
        }
      }
    }
    flag[FF_Id] = 0;
    printf("%d, %f\n", FF_Id + 1, eval[FF_Id]);
    fprintf(fout, "%d\n", FF_Id + 1);
    iNum--;
  }
}

void copy_back(double *eval)
{
  L_NODE *fnode;
  FIN_NODE *finnode;
  finnode=ffnode.next;
   for(int iff=0; finnode!=NULL; finnode=finnode->next,iff++){
          fnode=finnode->node;
          fnode->op_val=eval[iff];
          //printf("~%d %f %f~ ",fnode->line, fnode->op_val,eval[iff]);
   }
}
