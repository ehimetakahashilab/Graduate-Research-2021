//functions for controllability or observability computing
#ifndef __CPI_H__
#define __CPI_H__

#include "tpi_def.h"
#include "struct_eval.h"
#include "metric_eval.h"
#include "cop.h"
#include "initial.h"
#include "opi.h"

void c0_1_bias_cal(char *out_dir,char *circuit_name);

void refresh_all_cpnode();
void node_fixgate_for_cpi();
float gt_forw_trace_for_overlap(L_NODE *origin_node,int *nodes);
void full_ob_setting();
void cpi_main(float cp_rate,char *cplist_path);
float contribution_cal(int fix0, int fix1, float p0);
int all_routing_finish_check();
int explor_candi_cp_v2(L_NODE *candi_list[]);
int explor_candi_cp_every(L_NODE *candi_list[]);
void explor_candi_cp(L_NODE *candi_list[]);
void refresh_candi_cp(L_NODE **candi_list);
int pull_one_cp_by_cost(L_NODE **candi_list, int aviable_cp_num, int cplist_order[], L_NODE *cp_lists[], int sel_cp_num);
int pull_one_cp_by_expfc(L_NODE **candi_list,int aviable_cp_num,int cplist_order[],L_NODE *cp_lists[],int sel_cp_num);
int pull_one_cp_by_contrib(L_NODE **candi_list,int aviable_cp_num,int cplist_order[],L_NODE *cp_lists[],int sel_cp_num);
int pull_one_cp_by_DC(L_NODE **candi_list,int aviable_cp_num,int cplist_order[],L_NODE *cp_lists[],int nodes[],int sel_cp_num);
int pull_one_cp_by_boundary(L_NODE **candi_list, int aviable_cp_num, int cplist_order[], L_NODE *cp_lists[], int sel_cp_num);
void gt_forw_trace_for_overlap_updata(L_NODE *origin_node,int *nodes);
float gt_forw_trace_for_overlap(L_NODE *origin_node,int *nodes);
void swap_node(L_NODE *node1,L_NODE *node2);
void swap_float(float *a, float *b);
void swap_int(int *a,int *b);
int rank_candi_cp_by_c(L_NODE **candi_list,int cplist_order[]);

long double original_cost, new_cost;
#define cost_reducion_thd 99

#define CP_OFFSET 1 //CP選定する単位、=1:一つずつ選ぶ
#define CP_CANDI_RANGE 10 //CP選定する際の候補CP集合サイズ、CP_OFFSETの倍数
#define CP_CANDI_NUM  CP_CANDI_RANGE*CP_OFFSET //候補CP個数
#define PATNUM 10000 //故障検出率推定のためのパターン数
#define FCOV_INCREMENT_BOUND 0.0000 //推定故障検出の増量下限
#define FF_CP_SEL 0 //FFをCPとして選定するか
#define CAND_EXPLO 2 //=1:extract candi-cp by CO&contribution, =2: Extract candi-cp only by contribution =3: Extract candi-cp every gate
#define CP_ALG 3 //=1:DC =2:contribution =3: expexct fault coverage 

#define CP_KANETAKA 1
#if CP_KANETAKA
float observability_boundary_nodes(L_NODE *origin_node);
#endif
#endif
