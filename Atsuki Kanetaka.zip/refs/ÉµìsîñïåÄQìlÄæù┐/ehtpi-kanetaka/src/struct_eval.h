//functions for controllability or observability computing

#ifndef __STRUCT_EVAL_H__
#define __STRUCT_EVAL_H__
#include "tpi_def.h"
void ff_back_trace(FIN_NODE *ff_head);
void ff_back_trace_single(FIN_NODE *origin_node);

void ff_forw_trace(FIN_NODE *ff_head);
void ff_forw_trace_single(FIN_NODE *origin_node);

void ff_forw_trace_w_cpi(FIN_NODE *ff_head);

void trace_initial(L_NODE *gt_head,FIN_NODE *ff_head);
void gt_forw_trace(L_NODE *gt_head);
void gt_forw_trace_for_cpi(L_NODE *gt_head);
void gt_forw_trace_for_cpi_single(L_NODE *origin_node);
void fix_gt_check(L_NODE *origin_node,L_NODE *main_node,L_NODE *slave_node);
void boundary_node_search(L_NODE *origin_node);
void gt_back_trace(L_NODE *gt_head);
void gt_back_trace_single(L_NODE *origin_node);

void type1_3(L_NODE *gt_head,FIN_NODE *ff_head);


#endif
