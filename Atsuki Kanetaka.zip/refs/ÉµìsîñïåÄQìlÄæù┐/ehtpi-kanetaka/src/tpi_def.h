//- C File ------------------------------------------------------------
//
//  File Name    [head file .h]
//
//  System Name  [ehime TPI]
//
//  Module Name  [tpi.h]
//
//  Author       [Senling Wang]
//
//  Affiliation  [Ehime University]
//
//  Date         [2013]
//
//  Revision     [2016.4.1]
//
//----------------------------------------------------------------------
#ifndef __TPI_DEF_H__
#define __TPI_DEF_H__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/stat.h>
#include "math.h"
//#include "struct_eval.h"
/* gate type */
#define PI      0  /* primary input */
#define PO      4  /* primary output */
#define OR      1
#define AND     2
#define FAN     3  /* fanout branch */
#define NAND   -1
#define NOR    -2
#define NOT    -3
#define XOR     5
#define XNOR   -5
#define FF      6

#define FALSE 0
#define TRUE 1
#define Debug 0

/* signal value */
#define X 2
#define U 3
#define U0 4
#define U1 5
/* maximum limits */
#define MAXFLT  100000  /* maximum number of flist */
#define MAXCAP 20 /* maximum number of cycle capture */
#define MAXFFNUM 3600 /*Maximum number of FFs*/
#define MAXGTNUM 10000
#define SEQEN 1 //順序回路か、組合せ回路か
#define NAME 0 //回路名を見るか
#define REMOVEPO 1 //0:include PO (observable at each capture), 1:remove PO (observable at the last capture)
#define FFNAME 0 //FFの名前を見るか
#define MUGEN 999999999999999

#define FF_EXCLUDE 0
#define NODE_REC 1 //record all the tracable node

#define TP_EVALU_METRIC 1 //=0: expect fault coverage =1: cost function


typedef struct l_node L_NODE;
typedef struct fin_node FIN_NODE;
typedef struct flt_node FLT_NODE;

struct l_node
{
  int line,type,level,nfin,nfout; //Bisic structure information of wires
  int levelflag,sel_flag,cand_flag,flag,traced_flag,trace_flag;//flags
  int cp_flag,op_flag;
    //for structure analizing
  int fw_depth,fw_width,bk_depth,bk_width,fw_po_dis,bk_pi_dis;
  int gt_cnt[7][4];
  //COP and Scoap computing
  int o_cnt_flg,fanNum[MAXCAP],COfanNum[MAXCAP],fanCO[MAXCAP][20];
  double C0[MAXCAP],C1[MAXCAP],O[MAXCAP]; //for COP
  long int CC0[MAXCAP],CC1[MAXCAP],CO[MAXCAP]; //for SCOAP
  double fanO[MAXCAP][200];

    //for storing the fault information at each wire
  int fltList[MAXCAP];//the number of stuck-at fault
  int flttyp[MAXCAP];//the type of stuck-at fault
  double fltdetp[10][MAXCAP];//fault detection probability per cycel

  int tgl_gt_cnt[6];
  int fix_gt_0, fix_gt_1; //the number of gates in the forward cone, with fixed value by cpi
  int fix0,fix1,fix_val;
  float contri[MAXCAP];
  // the contribution gain by cpi contri=((𝑝0(𝑙)-0.5)∗𝑓0(𝑙)+(𝑝1(𝑙)-0.5)∗𝑓1(𝑙))

  int ff_in_path[MAXFFNUM],ff_out_path[MAXFFNUM];
  int bk_gt_list[MAXGTNUM/2];
  int eval_C[9];
  int total_branch;
  int arrive_branch;
  int fw_branch;
  double op_val;
  int TYPE[4];//for OPI selection
  L_NODE *next,*prev,*last;

  #if NODE_REC
  L_NODE *traced_node[MAXGTNUM];
  L_NODE *fw_traced_node[MAXGTNUM],*bk_traced_node[MAXGTNUM];
  L_NODE *boundary_node[MAXGTNUM];
  int traced_node_num,fw_traced_node_num,bk_traced_node_num;
  int boundary_node_num;
  #endif
  FIN_NODE *finlst,*foutlst;
} ;

struct fin_node
{
  L_NODE *node;
  FIN_NODE *next;
};

struct flt_node
{
  int saval,num;
  L_NODE *back,*forwd;
  FLT_NODE *next,*prev;
};

L_NODE gnode, inode;
FIN_NODE pinode,ponode,ffnode;
FLT_NODE fltlst;

/* net list */
typedef struct element {
       int type, nfi, nfo;
	   int fil; int fol;
	int redunt;
//	char name[100];
        }ELEMENT;


FILE *flist_out;

int lpnt,numout,inpnum,slist,ffnum,numgate,Cap,MaxLevel,sum_flt,node_num;
int CP_NUM; //control pointの数
char CirName[100],out_dir[100];
char op_path[300], cp_path[300];
typedef int CHGATA ; /* int when debugging, char otherwise */
#endif
