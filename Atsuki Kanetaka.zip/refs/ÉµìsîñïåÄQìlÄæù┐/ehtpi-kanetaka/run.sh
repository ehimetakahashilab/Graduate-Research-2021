#!bin/sh

User_DIR=$(cd "$(dirname "$0")";pwd)

OUT_DIR=${User_DIR}/OUTPUT
if [ ! -e ${OUT_DIR} ]; then
		mkdir -p ${OUT_DIR}/CP  ${OUT_DIR}/OP
fi
cpi_rate=0.01
opi_rate=0.2

ulimit -s unlimited
for f in s9234 s13207 s15850 s38417 s38584 b14s.osaka b15s.osaka b20s.osaka #s13207 s15850 s38584 b11s.osaka b12.osaka b14s.osaka b15s.osaka b20s.osaka #s38417 #s13207 #s9234 s13207 s15850 s38417 #s38584 #s344 s526 s832 s5378 #b11s.osaka b12.osaka b14s.osaka  #s208 #s344 s349 s382 s386 s400 s420 s444 s510 s526 s526n s641 s713 s820 s832 s838 s953 s1196 s1238 s1423 s1488 s1494 s5378 s9234 s13207 s15850 s35932 s38417 s38584  b01.osaka b02.osaka b03.osaka b04s.osaka b05s.osaka b06.osaka b07s.osaka b08.osaka b09.osaka b10.osaka b11s.osaka b12.osaka b13s.osaka b14s.osaka b15s.osaka b17s.osaka b20s.osaka b21s.osaka b22s.osaka #s5378 s9234 s13207 s1585 s38417 s38584 #s208 s344 s349 s382 s386 s400 s420 s444 s510 s526 s641 s713 s820 s832 s838 s953 s1196 s1238 s1423 s1488 s1494 s5378 s9234 s13207 s15850 s38417 s38584 #b15s.osaka b22s.osaka #s15850 s38417 s38584
#for f in s27 s208 s344 s349 s382 s386 s400 s420 s444 s510 s526 s526n s641 s713 s820 s832 s838 s953 s1196 s1238 s1423 s1488 s1494 s5378 s9234 s13207 s15850 s35932 s38417 s38584 NetList.v_osaka #
do

    ln -s ./circuit/$f

for Capture in 10 #1 2 3 4 5 #1 5 #1 2 3 4 5 6 7 8 9 10 #15 #20 #5 10 15 #20 #1 2 3 4 5 6 7 8 9 10 15 20
do
      echo === TestabilityComputation for $f ===
./ehime-tpi $f ${OUT_DIR} $Capture $cpi_rate $opi_rate #>>./log/$f.log

done
   rm -f $f  nfs000*
done
